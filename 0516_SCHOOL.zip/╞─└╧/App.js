import React,{Component} from "react";
import axios from "axios"
import "./App.css";
import {BrowserRouter,Routes,Route,Link} from "react-router-dom";
import queryString from "query-string";
import Home from "./components/Home/Home.js";
import Search from "./components/Search/Search.js";
import Search_Icon from "./components/Home/img/search_icon.png";
import Personal_Prodcut from "./components/Personal_product/Personal_product.js";
import Review_Board from "./components/Review_Board/Review_Board.js"
import Review_Board_detail from "./components/Review_Board_detail/Review_Board_detail.js"
import User_Login from "./components/User_Login/User_Login.js"
import User_LogOut from "./components/User_LogOut/User_LogOut.js"
import User_Login_Screen from "./components/User_Login_Screen/User_Login_Screen.js"
import Join_membership_screen from "./components/Join_membership_screen/Join_membership_screen.js"
import Create_review from "./components/Create_review/Create_review.js"

class App extends Component{
  constructor(props){
    super(props)

    this.state = {
      NoteBook : [
        {id : 7701 , name : "LG전자 그램 20년형 17인치 i5", image : "/img/Notebook/Notebook/LG_gram20_17_home.jpg" , price : 1560000,review:13,gpa : 4.8,iframe :"https://www.youtube.com/embed/hUCKW8YUkGM" , iframe2 :"https://www.youtube.com/embed/oUzRG2Mq9f0"},
        {id : 7702 ,name : "삼성전자 갤럭시북 플렉스 13인치 i5", image : "/img/Notebook/Notebook/galaxy_flex_13_i5_home.jpg" , price : 1700000 ,review:8,gpa : 4.3,iframe :"https://www.youtube.com/embed/kvSckomk2zM"},
        {id : 7703 ,name : "LG전자 그램 20년형 14인치 i5", image : "/img/Notebook/Notebook/LG_gram20_14_home.jpg" , price : 1130000 ,review:9,gpa : 4.4,iframe :"https://www.youtube.com/embed/oUzRG2Mq9f0"},
        {id : 7704 ,name : "삼성전자 갤럭시북 플렉스 13인치 i7", image : "/img/Notebook/Notebook/flex_13_i7_home.jpg" , price : 1800000 ,review:4,gpa : 4.2,iframe :"https://www.youtube.com/embed/S5k77vTzBjQ"},
        {id : 7705 ,name : "삼성전자 갤럭시북 이온 15인치 i5 MX250", image : "/img/Notebook/Notebook/ion_15_MX250_home.jpg" , price : 2560000,review:12,gpa : 4.1,iframe :"https://www.youtube.com/embed/NpTdUHjy-7E"},
        {id : 7706 ,name : "삼성전자 갤럭시북 플렉스 15인치 i5", image : "/img/Notebook/Notebook/fles_15_i5_home.jpg" , price : 1630000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/QmDBKJvstHk"},
        {id : 7707 ,name : "LG전자 그램19년형 15인치 i5", image : "/img/Notebook/Notebook/LG_gram15_15_home.jpg" , price : 1670000 ,review:7,gpa : 3.4,iframe :"https://www.youtube.com/embed/rT7CfkbE-UQ"},
        {id : 7708 ,name : "LG전자 그램 20년형 15인치i5", image : "/img/Notebook/Notebook/LG_gram19_15_home.jpg" , price : 1320000 ,review:8,gpa : 3.7,iframe :"https://www.youtube.com/embed/pz5CxHVBp4A"},
        {id : 7709 ,name : "삼성전자 노트북9 Always 19년형 15인치 i7 MX150", image : "/img/Notebook/Notebook/always_19_15_home.jpg" , price : 1140000 ,review:10,gpa : 2.8,iframe :"https://www.youtube.com/embed/iGX6lL2AkQk"},
        {id : 7710 ,name : "삼성전자 노트북9 Always 18년형 13인치 i7", image : "/img/Notebook/Notebook/always_18_13_home.jpg" , price : 2090000 ,review:2,gpa : 4.3,iframe :"https://www.youtube.com/embed/fIveStZwysA"},
      ],
      TV : [
        {id : 7801 ,name : "LG전자 울트라 HD TV AI 65인치", image : "/img/TV/TV/LG_ultra_ai_65.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7802 ,name : "삼성전자 The Sero 43인치", image : "/img/TV/TV/The_Sero_43.jpg" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7803 ,name : "LG전자 올레드 갤러리 TV 55인치", image : "/img/TV/TV/oled_gallery_55.jpeg" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7804 ,name : "LG전자 올레드 AI 55인치", image : "/img/TV/TV/oled_ai_55.jpeg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7805 ,name : "삼성전자 QLED 4K 65인치", image : "/img/TV/TV/qled_4k_65.jpeg" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
        {id : 7806 ,name : "삼성전자 The Serif 49인치", image : "/img/TV/TV/the_serif_49.jpeg" , price : 1660000 ,review:12,gpa : 4.2,iframe :"https://www.youtube.com/embed/rofMzCx_zFY"},
        {id : 7807 ,name : "삼성전자 QLED 4K 49인치", image : "/img/TV/TV/qled_4k_49.jpeg" , price : 710000 ,review:10,gpa : 4.3,iframe :"https://www.youtube.com/embed/SkvgxVvlyPo"},
        {id : 7808 ,name : "LG전자 울트라 HD TV AI 55인치", image : "/img/TV/TV/ultra_hd_ai_55.jpg" , price : 1100000 ,review:5,gpa : 2.8,iframe :"https://www.youtube.com/embed/A4xzVnM28o4"},
        {id : 7809 ,name : "LG전자 울트라 HD TV AI 75인치", image : "/img/TV/TV/ultra_hd_ai_75.jpg" , price : 1950000 ,review:2,gpa : 3.8,iframe :"https://www.youtube.com/embed/vvMVhZBbAg0"},
        {id : 7810 ,name : "삼성전자 Crystal UHD 55인치", image : "/img/TV/TV/crystal_uhd_55.jpeg" , price : 750000 ,review:7,gpa : 4.0,iframe :"https://www.youtube.com/embed/jQyVtn0rXaw"},
      ],
      Air_conditioner : [
        {id : 7901 ,name : "삼성 전자 무풍 에어컨", image : "https://www.samsungsales.co.kr/images/event/sales/ev_m_aircon_202009_01.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7902 ,name : "LG전자 휘센 듀얼 스페셜 17+7평", image : "https://www.lge.co.kr/kr/images/air-conditioners/md08045299/gallery/medium01.jpg" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7903 ,name : "삼성전자 무풍에어컨 무풍갤러리 19+6평 20년형", image : "https://yanolja001.godohosting.com/data/base/goods/big/AF17TX772FFRS_img.jpg" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7904 ,name : "LG전자 휘센 듀얼 프리미엄 20+7평", image : "https://www.lge.co.kr/kr/images/air-conditioners/md08045255/gallery/medium01.jpg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7905 ,name : "LG전자 휘센 듀얼 17평", image : "http://m.kemsystem.co.kr/web/product/big/202009/2321d4b884f14455fddd53849e712ed6.jpg" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
        
      ],
      Washing_machine : [
        {id : 7801 ,name : "LG전자 트롬 21kg", image : "https://www.lge.co.kr/kr/images/washing-machines/md08917869/gallery/medium01.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7802 ,name : "LG전자 트롬 17kg", image : "http://img.danawa.com/prod_img/500000/766/022/img/15022766_1.jpg?shrink=330:330&_v=20220420174443" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7803 ,name : "LG전자 트롬 14kg", image : "http://img.danawa.com/prod_img/500000/939/996/img/5996939_1.jpg?shrink=330:330&_v=20220119174810" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7804 ,name : "LG전자 통돌이 14kg", image : "http://th3.tmon.kr/thumbs/image/7c4/85d/639/9445045e0_700x700_95_FIT.jpg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7805 ,name : "삼성전자 워블 16kg", image : "http://img.danawa.com/prod_img/500000/042/536/img/12536042_1.jpg?shrink=330:330&_v=20201027171648" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
      ],

      view : "NoteBook",
    }
  }
  searchBook = () => {
    // window.location.href = "/personal_prodcut?product_id="+props.data.id+"&view="+view;
  }
  update_view = (data) => {
    this.setState({
      view : data
    })
  }

  jump_home = () => {
    window.location.href = "/";
  }

 componentDidMount(){
  // const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
  // console.log("/ queryObj :" ,queryObj.Login) //해당하는 물건의 이름
  // if(queryObj.Login == "true"){
  //   this.setState({
  //     Login : true,
  //     User_name : queryObj.Name,
  //   })
  // }
 }

  render(){

    if(window.sessionStorage.getItem("user_name") === null || window.sessionStorage.getItem("user_name") === "null"){
      var login = <User_Login

       />
    }
    else{
      var login = <User_LogOut
            
              />
    }
      return(
        <div id="App_wrap">
          
          <BrowserRouter>
              <div className="Logo" onClick={()=>this.jump_home()}>
                Logo
              </div>
              <div className="Search_product">
                  <input className="Search" placeholder="제품명 혹은 모델 명으로 검색하세요"></input>
                  <div className="Search_icon">
                      <img src={Search_Icon} onClick={this.searchBook}></img>
                  </div>
              </div>
  
              {login}
            <Routes>
  
                <Route exact path="/" element={<Home
                  NoteBook = {this.state.NoteBook}
                  TV = {this.state.TV}
                  Air_conditioner = {this.state.Air_conditioner}
                  Washing_machine = {this.state.Washing_machine}
                  update_view = {this.update_view}
                />}/>
  
                <Route path="/search" element={<Search
    
                />}/>
  
                <Route path="/personal_prodcut" element={<Personal_Prodcut //가전제품
                  view = {this.state.view}
                />}/>
  
                <Route path="/review_board" element={<Review_Board //가전제품
                />}/>
  
                <Route path="/review_board/detail" element={<Review_Board_detail //가전제품
                />}/>
  
                <Route path="/User_login" element={<User_Login_Screen //가전제품
                />}/>

                <Route path="/join_membership" element={<Join_membership_screen //가전제품
                />}/>

                <Route path="/create_review" element={<Create_review //가전제품
                />}/>
            </Routes>
  
            
          </BrowserRouter>
        </div>
      )
    
    }
  }
    


export default App;