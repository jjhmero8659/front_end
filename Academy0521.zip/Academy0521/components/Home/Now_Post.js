import React, {useState} from "react";
import "./css/Now_Post.css";


function Now_Post(props){

    const movie_detail = () => {
        window.location.href = "/movie_detail?Movie_name="+props.name+"&id="+props.id;
    }

	return(
		<div id="Now_Post_wrap">
            <div className="Now_image" onClick={()=>movie_detail()}>
                <img src={props.src}></img>
            </div>
            <div className="Now_name">
                {props.name}
            </div>
            <div className="now_sale_rate">
                예매율 : <span>{props.sale_rate}</span> 
            </div>
            <div className="now_gpa">
                평점 : <span>{props.gpa}</span>
            </div>
		</div>
	)
}

export default Now_Post;