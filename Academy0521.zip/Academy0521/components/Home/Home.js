import React, {useState,useEffect} from "react";
import "./css/Home.css";
import Now_PagiNation from "./Now_PagiNation.js";
import Now_Posts from "./Now_Posts.js";
import axios from "axios";
import Slick from "./Slick.js";
import "slick-carousel/slick/slick.css" 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

function Home(){

    const [Current_page,set_current] = useState(1)
    const [Page_per_page,set_Page_per_page] = useState(5)

    const [tobe_Current_page,set_tobe_current] = useState(1)
    const [tobe_Page_per_page,set_Page_tobe_per_page] = useState(5)
    const [Now_Movie,set_now_movie] = useState([])
    const [Tobe_Movie,set_tobe_Movie] = useState([])

    useEffect(()=>{
        get_now_movie();
        get_tobe_movie();
    },[])

    const get_now_movie = async() => {
        const res = await axios.get('/api/get/now_movie')
        set_now_movie(res.data.Movie_now)
    }

    const get_tobe_movie = async() => {
        const res = await axios.get('/api/get_tobe/tobe_movie')
        set_tobe_Movie(res.data.Movie_tobe)
    }

    const update_current = (data) => {
        set_current(
            data
        )
    }

    const tobe_update_current = (data) => {
        set_tobe_current(
            data
        )
    }
    const app_settings = { 
        fade:true,
        autoplay : true,
        dots: false, 
        infinite: true, 
        speed: 1000, 
        slidesToShow: 1, 
        slidesToScroll: 1 
      };
	return(
		<div id="Home_wrap">
            <div className="over">
                <div className="Slick_wrap">
                    <div className="over_cutton"></div>
                    <Slick/>
                    <div className="under_cutton"></div>
                </div>

                <div className="Now_page_wrap">
                    <div className="head_text">
                        현재 상영 영화
                    </div>
                    <Now_Posts
                        Now_Movie = {Now_Movie}
                        Current_page = {Current_page}
                        Page_per_page = {Page_per_page}
                    />
                    <Now_PagiNation
                        total = {Now_Movie.length}
                        Current_page = {Current_page}
                        Page_per_page = {Page_per_page}
                        update_current = {update_current}
                    />
                </div>

                <div className="Tobe_page_wrap">
                    <div className="head_text">
                        상영 예정 영화
                    </div>

                    <Now_Posts
                        Now_Movie = {Tobe_Movie}
                        Current_page = {tobe_Current_page}
                        Page_per_page = {tobe_Page_per_page}
                    />
                    <Now_PagiNation
                        total = {Tobe_Movie.length}
                        Current_page = {tobe_Current_page}
                        Page_per_page = {tobe_Page_per_page}
                        update_current = {tobe_update_current}
                    />
                </div>
            </div>
            <div className="under">
                <div className="Special_theater">
                    <div className="p_wrap">
                        <p>스페셜관</p>
                        <p>더보기</p>
                    </div>
                    <div className="theater_img">
                        <a><img src="/src/under/charlotte.png"></img></a>
                        <a><img src="/src/under/cineComfort.png"></img></a>
                        <a><img src="/src/under/cinesalon.png"></img></a>
                        <a><img src="/src/under/colorium.png"></img></a>
                        <a><img src="/src/under/super_plex_del_g.png"></img></a>
                        <a><img src="/src/under/super_plex.png"></img></a>
                        <a><img src="/src/under/super4d.png"></img></a>
                        <a><img src="/src/under/superS.png"></img></a>
                        <a><img src="/src/under/superS.png"></img></a>
                    </div>
                </div>
                <div className="Event_Wrap">
                    <div className="p_wrap">
                        <p>이벤트</p>
                        <p>더보기</p>
                    </div>
                    <div className="Event_img">
                        <div>
                            <img src="/src/Event/toss.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/Event/lotte_cinema.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/Event/artbook.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/Event/mileage.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/Event/kickgoing.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/Event/membership.jpg"></img>
                        </div>
                    </div>
                </div>

                <div className="Preview_wrap">
                    <div className="p_wrap">
                        <p>시사회/무대인사</p>
                        <p>더보기</p>
                    </div>
                    <div className="Preview_img">
                        <div>
                            <img src="/src/preview_img/img1.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/preview_img/img2.jpg"></img>
                        </div>
                        <div>
                            <img src="/src/preview_img/img3.jpg"></img>
                        </div>
                    </div>
                </div>

                <div className="Benefit_wrap">
                    <div>
                        <img src="/src/under/sale.png"></img>
                    </div>
                    <div>
                        <img src="/src/under/point.png"></img>
                    </div>
                    <div>
                        <img src="/src/under/membership.png"></img>
                    </div>
                    <div>
                        <img src="/src/under/club.png"></img>
                    </div>
                    <div>
                        <img src="/src/under/bravo.png"></img>
                    </div>
                </div>

                <div className="footer_image_wrap">
                    <Slider {...app_settings}>
                        <div><a><img src="/src/under_footer/Jokuk.jpg"></img></a></div>
                        <div><a><img src="/src/under_footer/Doctor.jpg"></img></a></div>
                    </Slider>
                    
                </div>

                <div className="footer_image2_wrap">
                    <a><img src="/src/under_footer/Hyundaicard.jpg"></img></a>
                </div>
            </div>
		</div>
	)
}

export default Home;