import React, {useState,useEffect} from "react";
import "./css/Detail_Movie.css";
import queryString from "query-string";
import axios from "axios";
import Movie_info from "./Movie_info.js";
import Movie_board from "./Movie_board.js";

function Detail_Movie(){

    const [mv_id,set_id] = useState("");
    const [Movie,set_Movie] = useState([]);
    const [Board,set_Board] = useState([]);

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log("Detail",queryObj.id)

        get_movie_detail(queryObj.id);
        get_movie_board(queryObj.id);

        set_id(queryObj.id)
    },[])


    const get_movie_detail = async(id) => {
        const res = await axios.get(`/api/get/detail_movie${id}`);
        set_Movie(
            res.data.Movie_Detail
        )
    };

    const get_movie_board = async(id) => {
        const res = await axios.get(`/api/get/movie_board${id}`);
        set_Board(
            res.data.Board_list
        )
    };

    var Movie_info_map = Movie.map(
        (data,index) => (
            <Movie_info
                key={index}
                data = {data}
            />
        )
    )

    // var Movie_board_map = Board.map(
    //     (data,index) => (
    //         <Movie_board
    //             key={index}
    //             data = {data}
    //         />
    //     )
    // )

    return(
        <div id="Detail_Movie_wrap">
            {Movie_info_map}
            <Movie_board
                Board = {Board}
                id = {mv_id}
            />
        </div>
    )
}

export default Detail_Movie;