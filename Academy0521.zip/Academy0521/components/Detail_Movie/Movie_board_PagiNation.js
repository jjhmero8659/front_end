import React, {useState} from "react";
import "./css/Movie_board_PagiNation.css";


function Movie_board_PagiNation_Post(props){

    const icon_click = (data) => {
        props.update_current(data)
    }

    var page = [];
    for(var i=1; i<=Math.ceil(props.total_len / props.Page_per_page); i++){
        page.push(i)
    }

    var page_icon =page.map(
        (data,index) => (
            <div key={index} className="page_icon" onClick={()=>icon_click(data)}>{data}</div> 
        )
    )
	return(
		<div id="Movie_board_PagiNation_wrap">
            {page_icon}
		</div>
	)
}

export default Movie_board_PagiNation_Post;