import React, {useState} from "react";
import "./css/Movie_info.css";


function Movie_info(props){
    console.log("Movie_info",props)
	return(
		<div id="Movie_info_wrap">
            <div className="gpa">
                <img src="https://www.lottecinema.co.kr/NLCHS/Content/images/icon/star_14.png"></img>
                <p>평점 <span>{props.data.gpa}</span></p>
            </div>
            <div className="name">
                {props.data.name}
            </div>
            <div className="image">
                <img src={props.data.src}></img>
            </div>
            <div className="summary">
                {props.data.summary}
            </div>
            <div className="sale_rate">
                예매율 : <span>{props.data.sale_rate}</span>
            </div>
            <div className="time">
                상영시간 : <span>{props.data.time}</span> 분
            </div>
            <div className="Director">
                감독 : <span>{props.data.Director}</span>
            </div>
            <div className="ganre">
                장르 : <span>{props.data.Genre}</span>
            </div>
            <div className="iframe1">
                <iframe width="490" height="315" src={props.data.iframe1} title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
            </div>
            <div className="iframe2">
                <iframe width="490" height="315" src={props.data.iframe2} title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
            </div>
            <div className="Board_head_text">
                <a href="#">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    {props.data.name} 의 관객 후기
                </a>
            </div>
		</div>
	)
}

export default Movie_info;