import React, {useState,useEffect} from "react";
import "./css/Under_movie.css";
import queryString from "query-string";


function Under_movie(){

    useEffect(()=>{
    },[])

	return(
		<div id="Under_movie_wrap">
            <div className="top_banner">
                <img src="/src/Home_poster/jokuk_slide.jpg"></img>
            </div>

            <div className="now_movie">
                <div className="head_text">
                    <p>현재 상영작 <span>TOP 5</span> </p>
                </div>
            </div>


            <div className="next_movie">
                <div className="head_text">
                    <p>상영 예정작 <span>TOP 5</span> </p>
                </div>
            </div>

            <div className="movie_list">
                <div className="list_first">

                </div>
                <div className="list_second">

                </div>
                <div className="list_third">

                </div>
            </div>
		</div>
	)
}

export default Under_movie;