import React, {useState,useEffect} from "react";
import "./css/User_login_screen.css";
import queryString from "query-string";
import axios from "axios";


function User_login_screen(){

    const [id,set_id] = useState("");
    const [pw,set_pw] = useState("");

    const [maintain_check,set_maintain_check] = useState(false);
    // const [Name,set_Name] = useState("");

    const onchange_id = (e) => {
        set_id(e.target.value)
    }

    const onchange_pw = (e) => {
        set_pw(e.target.value)
    }

    const check_input = async(e) => {
        const res = await axios.get(`/api/get_user_login/user_info${id}&${pw}`);

        if(res.data.data.length == 0){

            alert("ID 또는 Password 가 틀렸습니다.");
        }
        else{
            window.sessionStorage.setItem("user_name", res.data.data[0].name);
            window.sessionStorage.setItem("user_id", id);
            window.sessionStorage.setItem("user_pw", pw);
            window.location.href = "/"
            // console.log("storage_user_id",localStorage.getItem('user_id'));
            // console.log("storage_user_pw",localStorage.getItem('user_pw'));
        }
    }

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log(queryObj)
    },[])

	return(
		<div id="User_login_screen_wrap">
            <div className="input_wrap_back">
                <div className="Login_input_wrap">

                    <div className="member"> {/* 멤버 버튼 */}
                        <p className="text_info">
                            L.POINT, 롯데시네마 ID로 별도의 회원가입 없이 이용 가능 합니다.
                        </p>
                        <input className="input_id" type="text" placeholder="아이디를 입력하세요" onChange={(e)=>onchange_id(e)}></input>
                        <input className="input_pw" type="password" placeholder="비밀번호 를 입력하세요" onChange={(e)=>onchange_pw(e)}></input>
                        <div className="Maintain_Status" onClick={()=>set_maintain_check(!maintain_check)}>
                            <div id="maintain_image" className={(maintain_check == true) ? "active" : null}>

                            </div>
                            <p>로그인 상태 유지</p>
                        </div>
                        <div className="Login_btn" onClick={()=>check_input()}>
                            로그인
                        </div>
                        <div className="minwise_advertise">
                            <img src="/src/Advertise/Minwise.png"></img>
                        </div>
                        <div className="aton_advertise">
                            <img src="/src/Advertise/Aton.png"></img>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="sub_menu">
                <div className="find_id">아이디 찾기</div>
                <div className="find_pw">비밀번호 찾기</div>
                <div className="join_membership">회원가입</div>
            </div>
           

            <div className="movie_jokuk">
                <img src="/src/Advertise/Jokuk_footer.jpg"></img>
            </div>

            <div className="footer_advertise">
                <img src="/src/Advertise/Hyundaicard.jpg"></img>
            </div>
		</div>
	)
}

export default User_login_screen;