import {BrowserRouter,Routes,Route} from "react-router-dom";
import React, {useState,useEffect} from "react";
import Home from "./components/Home/Home.js";
import Search from "./components/Search/Search.js";
import Detail_Movie from "./components/Detail_Movie/Detail_Movie.js";
import Detail_Board from "./components/Detail_Board/Detail_Board.js";
import User_Login from "./components/User_Login/User_Login.js";
import User_Logout from "./components/User_Logout/User_Logout.js";
import User_login_screen from "./components/User_login_screen/User_login_screen.js";
import Under_movie from "./components/Under_movie/Under_movie.js";
import "./App.css";
import axios from "axios";
import $ from "jquery";
import jquery from "jquery";

function App(){

  const [Searchtext, Set_Searchtext] = useState("");
  const [Login_status, Set_Login_status] = useState("false");
  const [movie_id,set_movie_id] = useState("")
  // const [status,set_status] = useState("")

  useEffect(()=>{
    $(function(){
        $(".under .menu>div").hover(
          function(e){
            e.stopImmediatePropagation()
            $(this).find("ul").stop().fadeToggle(200);
            $(".ul_back").stop().fadeToggle(200);
          }
        )
    })
  },[])

  const search_btn = async() => {
    const res = await axios.get(`/api/search/get_id${Searchtext}`)
    set_movie_id(res.data.data[0].id);
    // window.location.href = "/movie_detail?Movie_name="+Searchtext+"&id="+props.id;
  }

  const under_movie_click = () => {
    window.location.href = "/logo_under_movie"
  }

  useEffect(()=>{
    if(movie_id != ""){
      window.location.href = "/movie_detail?Movie_name="+Searchtext+"&id="+movie_id;
    }
    else if(movie_id == ""){

    }
    else{

    }
  },[movie_id])


  const input_search = (e) => {
    Set_Searchtext(
      e.target.value
    )
  }

  useEffect(()=>{
    // console.log("APPstorage_user_name",sessionStorage.getItem('user_name'));
  },[])

  const search_keypress = (e) => {
    if(e.code == "Enter"){
      search_btn();
    }
  }
  const logo_click = () => {
    window.location.href = "/"
  }

  const login_click = () => {
    window.location.href = "/User_login"
  }

  if(sessionStorage.getItem('user_name') == null || sessionStorage.getItem('user_name') === "null"){
    var User_status = <User_Login />
  }
  else{
    var User_status = <User_Logout
        user_name = {sessionStorage.getItem('user_name')}
    />
  }
  // var img_src = "./src/logo512.png";

  
  return(

    
    <div id="App_wrap">
      
      <BrowserRouter>
      {/* {
        console.log('slice',window.location.href.slice(21))
      }
      {
        
        console.log('location',window.location.href.search("/"))
      } */}
          <div id="logo" className={((window.location.href.slice(21) == "/User_login") || (window.location.href.slice(21)) == "/logo_under_movie") ? "active" : null}>
            <div class="over">
                <a><img src="./src/Cinema_header/logo.png"  onClick={()=>logo_click()}></img></a>
                <div className="left_side">
                  <div className="face_book">
                      <a href="#">페이스북</a>
                  </div>
                  <div className="youtube">
                      <a href="#">유튜브</a>
                  </div>
                  <div className="instagram">
                      <a href="#">인스타그램</a>
                  </div>
                </div>
                <div className="right_side">
                  <div className="customer_service">
                      <a href="https://www.lottecinema.co.kr/NLCHS/Customer">고객센터</a>
                  </div>
                  <div className="membership">
                      <a href="https://www.lottecinema.co.kr/NLCHS/Mypage/MemberVipzone">멤버십</a>
                  </div>
                  {User_status}
              </div>

              <div className="under">
                <div className="menu">
                   <div className="Reservation">
                        <a href="#">예매</a>
                        <ul>
                          <li><a>예매하기</a></li>
                          <li><a>상영시간표</a></li>
                          <li><a>할인안내</a></li>
                        </ul>
                    </div>
                    <div className="movie">
                        <a href="#" onClick={()=>under_movie_click()}>영화</a>
                        <ul>
                          <li><a>홈</a></li>
                          <li><a>현재 상영작</a></li>
                          <li><a>상영 예정작</a></li>
                          <li><a>아르떼</a></li>
                          <li><a>국립극장</a></li>
                        </ul>
                    </div>
                    <div className="movie_theater">
                        <a href="#">영화관</a>
                        <ul>
                          <li><a>스페셜관</a></li>
                          <li><a>서울</a></li>
                          <li><a>경기/인천</a></li>
                          <li><a>충청/대전</a></li>
                          <li><a>전라/광주</a></li>
                          <li><a>경북/대구</a></li>
                          <li><a>경남/부산/울산</a></li>
                          <li><a>강원</a></li>
                          <li><a>제주</a></li>
                        </ul>
                    </div>
                    <div className="event">
                        <a href="#">이벤트</a>
                        <ul>
                          <li><a>홈</a></li>
                          <li><a>영화</a></li>
                          <li><a>시사회/무대인사</a></li>
                          <li><a>HOT</a></li>
                          <li><a>제휴할인</a></li>
                          <li><a>우리동네 영화관</a></li>
                        </ul>
                    </div>
                    <div className="store">
                        <a href="#">스토어</a>
                        <ul>
                          <li><a>베스트</a></li>
                          <li><a>관람권</a></li>
                          <li><a>스낵음료</a></li>
                          <li><a>포토카드</a></li>
                        </ul>
                    </div>
                </div>
              </div>
            </div>
            
          </div>
          <div className="ul_back"></div>
          {/* <div id="input_wrap">
              <input type="text" placeholder="검색어를 입력하세요" onChange={(e)=>input_search(e)} onKeyPress={(e)=>search_keypress(e)}></input>
              <button className="Search_btn" onClick={()=>search_btn()}>검색</button>
          </div> */}
          
          <Routes>
              <Route exact path="/" element={<Home/>}/>
              <Route path="/search" element={<Search/>}/>
              <Route path="/movie_detail" element={<Detail_Movie/>}/>
              <Route path="/board_detail" element={<Detail_Board/>}/>
              <Route path="/User_login" element={<User_login_screen/>}/>
              <Route path="/logo_under_movie" element={<Under_movie/>}/>
          </Routes>
        </BrowserRouter>
    </div>
  )
}

export default App;