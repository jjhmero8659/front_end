// import React , {Component} from "react";
// import "./css/Product_board.css";

// class Product_board extends Component{
//     constructor(props){
//         super(props)

//         this.state = {

//         }
//     }

//     render(){
//         return(
//             <div id="Product_board_wrap">

//             </div>
//         )
//     }
// }

// export default Product_board;


import React , {useEffect, useState} from "react";
import Product_board_post from "./Product_board_post.js";
import axios from "axios";
import "./css/Product_board.css";

function Product_board(props){
    const [product_id,set_product_id] = useState("")


    useEffect(()=>{
        set_product_id(props.product_id)
    },[])

    console.log("dwqdqw",props.review)
    const Representative_review = props.review.map(
        (data,index) => (<Product_board_post
            key={index}
            name = {data.name}
            review = {data.review}
            good_rec = {data.good_rec}
            bad_rec = {data.bad_rec}
        />)
    )

    console.log("Representative_review",Representative_review)

    return(
        <div id="Product_board_wrap">
            <div className="board_header">
                사용자 대표 리뷰
            </div>
            {Representative_review}
        </div>
    )
}

export default Product_board;