import React , {Component} from "react";
import "./css/Search.css";


class Search extends Component{
    constructor(props){
        super(props)

        this.state = {

        }
    }

    render(){
        console.log(this.props.view)
        return(
            <div id="Search_wrap">

            </div>
        )
    }
}

export default Search;