import React,{Component} from "react";
import "./css/Slide_Banner.css";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";




class Slide_Banner extends Component{
  constructor(props){
    super(props)

    this.state = {

    }
  }

  

  render(){
    const settings = {
        // fade : true,
        dots: false,
        autoplay:true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };
    return(
      <div id="Slide_Banner_wrap">
          <Slider {...settings}>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfMjU0/MDAxNTA4NzYyNDI1NzMy.Hsb6u_UmhU1kesgBZS50C8UDS1HPTefFy41azTicZNQg.LuM8Qfhj0B6W9_UKpjZjZGPqyI21gytmVIaoR2ppAzcg.JPEG.knicjin/20171023_013.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfOTIg/MDAxNTA4NzYyNDIyNjY4.LWEIPxqqAV6wgVramzlKmKKDxNREyq0uHiJ2Ty3o5CEg.YFXoZFpA4294B9pK75WosJYasBCtd4DL-M3aIogW2w8g.JPEG.knicjin/20171023_007.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfMjgy/MDAxNTA4NzYyNDI2MTUx.v9bAdr5OeU473bBjyz34JfGkEQ3l3C-omblZobXmN6kg.vqFJW4LjYbhBAVBMnBmMpM2TvmKPQID0jY1bJC6uc1Ig.JPEG.knicjin/20171023_014.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfNjMg/MDAxNTA4NzYyNDMzMjg4.u_CCgCrPT8u5WyyRE0RGzlKuYMP-d-np8GDYbU3t7zUg.nKAKhdo-k3vnF9slQgZuJMyGK_ZIfTWIiZwM7yj5p1kg.JPEG.knicjin/20171023_028.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfNzUg/MDAxNTA4NzYyNDM5Mjk5.452uXMo5NnKIYRs9aUKmagolXexRgNiCDa9X6r5BEHYg.a_W6xuags52vKztEeqjsUmbxWFwoewFcVIZMLWenJYkg.JPEG.knicjin/20171023_043.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfMzYg/MDAxNTA4NzYyNDM5MDIz.7iRwqXg6wByw9BH1kA7_T5Ni1oejLBnEYGOBowPSjwog._bV0kHwoullpIfFKE7kWlJDpgHv4WBjWtH5xta9dFuQg.JPEG.knicjin/20171023_040.jpg?type=w800"}></img>
            </div>
        </Slider>
        <div id="transparency" className="left"></div>
        <div id="transparency" className="right"></div>
      </div>
    )
  }
}

export default Slide_Banner;