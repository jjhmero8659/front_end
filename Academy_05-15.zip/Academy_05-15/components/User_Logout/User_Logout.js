import React, {useState,useEffect} from "react";
import "./css/User_Logout.css";
import queryString from "query-string";
import $ from "jquery";


function User_Logout(props){

    useEffect(()=>{
        $(function(){
            $("#User_Logout_wrap").hover(
                function(e){
                    e.stopImmediatePropagation();
                    $(".LogOut_slide").stop().slideToggle(200);
                }
            )
        })
    },[])

    const user_logout = () => {
        window.sessionStorage.setItem("user_name", null);
        window.sessionStorage.setItem("user_id", null);
        window.sessionStorage.setItem("user_pw", null);
        window.location.href = "/";
    }

	return(
		<div id="User_Logout_wrap">
            {props.user_name} 님
            <ul className="LogOut_slide">
                <li><a href="#">마이페이지</a></li>
                <li><a href="#"  onClick={()=>user_logout()}>로그아웃</a></li>
            </ul>
		</div>
	)
}

export default User_Logout;