import React, {useState} from "react";
import "./css/Movie_board.css";
import Movie_board_Post from "./Movie_board_Post.js";
import Movie_board_PagiNation from "./Movie_board_PagiNation.js";


function Movie_board(props){

    const [Current_page,set_current_page] = useState(1);
    const [Page_per_page,set_per_page] = useState(7);

    const slice_list = (data) => {
        var indexOfLast = Page_per_page * Current_page;
        var indexOfFirst = indexOfLast - Page_per_page;

        var slice_res = data.slice(indexOfFirst,indexOfLast);
        return slice_res;
    }

    var slice_board = slice_list(props.Board).map(
        (data,index) => (<Movie_board_Post
            key={index}
            data={data}
            id={props.id}
        />)
    )
    const update_current = (data) => {
        set_current_page(data)
    }
	return(
		<div id="Movie_board_wrap">
            <div className="board_head">
                <div className="num">
                    번호
                </div>
                <div className="title">
                    제목
                </div>
                <div className="writer">
                    작성자
                </div>
                <div className="date">
                    등록일
                </div>
                <div className="attach">
                    첨부
                </div>
                <div className="inquiry">
                    조회
                </div>
            </div>
            {slice_board}
            <Movie_board_PagiNation
                total_len = {props.Board.length}
                Current_page = {Current_page}
                Page_per_page = {Page_per_page}
                update_current = {update_current}
            />
		</div>
	)
}

export default Movie_board;