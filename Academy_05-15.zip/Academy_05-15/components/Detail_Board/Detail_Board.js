import React, {useState,useEffect} from "react";
import "./css/Detail_Board.css";
import queryString from "query-string";
import axios from "axios";
import User_review from "./User_review.js";


function Detail_Board(props){
    const [review_data,set_review_data] = useState([]);
    const [id,set_id] = useState("");
    const [Modify_summary,set_summary] = useState("");

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        // console.log("BDetail",queryObj.id)
        // console.log("BDetail",queryObj.writer)

        get_user_review(queryObj.id,queryObj.writer);
        set_id(queryObj.id)
    },[])

    const update_summary = async(summary) => {
        set_summary(summary)
        const res = await axios.put(`/api/modify/modify_summary${id}&${summary}&${review_data[0].title}&${review_data[0].writer}`)
    }

    const get_user_review = async(id,writer) => {
        const res = await axios.get(`/api/get/user_review${id}&${writer}`)
        set_review_data(res.data.user_review)
    } 

    const user_review = review_data.map(
        (data,index)=>  <User_review
            key = {index}
            update_summary = {update_summary}
            summary = {data.summary}
            Modify_summary = {Modify_summary}
            title = {data.title}
            writer = {data.writer}
            date = {data.date}
            inquiry = {data.inquiry}
            movie_id = {id}
        />
    )

	return(
		<div id="Detail_Board_wrap">
           {user_review}
		</div>
	)
}

export default Detail_Board;