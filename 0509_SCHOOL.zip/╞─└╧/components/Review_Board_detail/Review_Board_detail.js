import React , {useEffect, useState} from "react";
import "./css/Review_Board_detail.css";
import queryString from "query-string";
import axios from "axios";
import Summary_text from "./Summary_text.js";

function Review_Board_detail(props){

    const [review,set_review] = useState([]);
    const [pro_id,set_pro_id] = useState("");
    const [update_summary, set_update_summary] = useState("");

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
        // console.log("queryObj :" ,queryObj.pro_id) //해당하는 물건의 이름
        // console.log("queryObj :" ,queryObj.user_name)
        get_review_person(queryObj.pro_id,queryObj.user_name)

        set_pro_id(queryObj.pro_id)
    },[])

    const get_review_person = async(id,name) => {
        const res = await axios.get(`/api/get_review_person/get_review${id}&${name}`) 
        set_update_summary(res.data.Review[0].summary)
        set_review(res.data.Review[0])
    }

    const modify_summary = async(summary) => {
        set_update_summary(summary)
        const res = await axios.put(`/api/put/modify_summary${pro_id}&${summary}&${review.name}&${review.title}`);
    }
    
    return(
        <div id="Review_Board_border">
            <div id="Review_Board_detail_wrap">
                <div className="Review_title_wrap">
                    <p>제목</p>
                    <div className="Reivew_title">
                        {review.title}
                    </div>
                </div>
                <div className="Review_writer_wrap">
                    <p>작성자</p>
                    <div className="Reivew_writer">
                        {review.name}
                    </div>
                    <p>등록일</p>
                    <div className="Reivew_date">
                        {review.date}
                    </div>
                    <p>조회</p>
                    <div className="Reivew_inquiry">
                        {review.inquiry}
                    </div>
                    <p>추천 수</p>
                    <div className="Reivew_good_rec">
                        {review.good_rec}
                    </div>
                </div>
                <div className="Reivew_summary_wrap">
                    <div class="summary_header">
                        글 내용
                    </div>
                    <Summary_text
                        pro_id = {pro_id}
                        name = {review.name}
                        bagic_summary = {review.summary}
                        summary_text = {update_summary}
                        modify_summary = {modify_summary}
                    />
                </div>
            </div>
        </div>
    )
}

export default Review_Board_detail;