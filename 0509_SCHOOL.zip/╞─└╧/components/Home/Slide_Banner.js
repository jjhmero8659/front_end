import React,{Component} from "react";
import "./css/Slide_Banner.css";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";




class Slide_Banner extends Component{
  constructor(props){
    super(props)

    this.state = {

    }
  }

  

  render(){
    const settings = {
        // fade : true,
        dots: true,
        autoplay:true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };

    const banner_click = () => {
      alert("hi")
    }

    return(
      <div id="Slide_Banner_wrap">
          <Slider {...settings}>
            <div>
                <img src={"https://d21x3meyyr2jva.cloudfront.net/banner/pc/%EC%84%A0%ED%92%8D%EA%B8%B0_pc_1650619744168.png"} onClick={()=>banner_click()}></img>
            </div>
            <div>
                <img src={"https://d21x3meyyr2jva.cloudfront.net/banner/pc/%EC%97%90%EC%96%B4%EC%BB%A8_pc_1650619743992.png"} onClick={()=>banner_click()}></img>
            </div>
            <div>
                <img src={"https://d21x3meyyr2jva.cloudfront.net/banner/pc/%EC%BA%A1%EC%8A%90%EC%BB%A4%ED%94%BC1_pc_1650619744215.png"} onClick={()=>banner_click()}></img>
            </div>
            <div>
                <img src={"https://d21x3meyyr2jva.cloudfront.net/banner/pc/%EC%99%80%ED%94%8C%EB%A9%94%EC%9D%B4%EC%BB%A4_2_1650619744459.png"} onClick={()=>banner_click()}></img>
            </div>
            <div>
                <img src={"https://dvd6ljcj7w3pj.cloudfront.net/media/BANNER/409b0242-d169-48c6-ac29-462d40fce593"} onClick={()=>banner_click()}></img>
            </div>
            {/* <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfNzUg/MDAxNTA4NzYyNDM5Mjk5.452uXMo5NnKIYRs9aUKmagolXexRgNiCDa9X6r5BEHYg.a_W6xuags52vKztEeqjsUmbxWFwoewFcVIZMLWenJYkg.JPEG.knicjin/20171023_043.jpg?type=w800"}></img>
            </div>
            <div>
                <img src={"https://mblogthumb-phinf.pstatic.net/MjAxNzEwMjNfMzYg/MDAxNTA4NzYyNDM5MDIz.7iRwqXg6wByw9BH1kA7_T5Ni1oejLBnEYGOBowPSjwog._bV0kHwoullpIfFKE7kWlJDpgHv4WBjWtH5xta9dFuQg.JPEG.knicjin/20171023_040.jpg?type=w800"}></img>
            </div> */}
        </Slider>
        <div id="transparency" className="left"></div>
        <div id="transparency" className="right"></div>
      </div>
    )
  }
}

export default Slide_Banner;