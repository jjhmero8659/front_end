import React, {Component} from "react";
import "../css/Change_Post.css";


class Change_Post extends Component{
    constructor(props){
        super(props)

        this.state = {
            
        }
    }

    update_view = (data) => {
        this.props.update_view(data);
    }

    render(){
        return(
            <div id="Change_Post_wrap">
                <div id="NoteBook" className="Product_button" onClick={()=>this.update_view("NoteBook")}>노트북</div>
                <div id="TV" className="Product_button" onClick={()=>this.update_view("TV")}>TV</div>
                <div id="Air_conditioner" className="Product_button" onClick={()=>this.update_view("Air_conditioner")}>에어컨</div>
                <div id="washing_machine" className="Product_button" onClick={()=>this.update_view("Washing_machine")}>세탁기</div>
                <div id="fan" className="Product_button" onClick={()=>this.update_view("fan")}>선풍기</div>
                <div id="Humidifier" className="Product_button" onClick={()=>this.update_view("Humidifier")}>가습기</div>
                <div id="wireless_earphones" className="Product_button" onClick={()=>this.update_view("wireless_earphones")}>무선이어폰</div>
                <div id="Air_purifier" className="Product_button" onClick={()=>this.update_view("Air_purifier")}>공기청정기</div>
            </div>
        )
    }
}

export default Change_Post;