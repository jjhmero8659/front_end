import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/User_Login_Screen.css";


function User_Login_Screen(props){

    // const [Login_status , set_Login_status] = useState(false)
    const [user_id,set_id] = useState("");
    const [user_pw,set_pw] = useState("");
    const [user_info,set_userinfo] = useState([]);
    const [active_status,set_active_status] = useState(false);

    const check_log_info = async() => {
        const res = await axios.get(`/api/check/user_login${user_id}&${user_pw}`);
        console.log(res.data.User_info[0].name)
        if(res.data.User_info.length == 0){
            alert("ID 또는 Password 가 틀렸습니다.")
        }
        else{
            window.sessionStorage.setItem("user_name",res.data.User_info[0].name);
            window.sessionStorage.setItem("user_id",user_id);
            window.sessionStorage.setItem("user_pw",user_pw);

            window.location.href = "/";
        }
    }

    const onchange_id = (e) => {
        set_id(e.target.value)
    }

    const onchange_pw = (e) => {
        set_pw(e.target.value)
    }

    // useEffect(()=>{
        
    // },[check_log_info()])



    return(
        <div id="User_Login_Screen_wrap">
            <div class="logo">
                LOGO
            </div>
            <div className="Login">
                <input className="input_id" type="text" placeholder="아이디 를 입력해주세요" onChange={(e)=>onchange_id(e)}></input>
                <input className="input_pw" type="password" placeholder="비밀번호 를 입력해주세요" onChange={(e)=>onchange_pw(e)}></input>
                <div className="Login_btn" onClick={()=>check_log_info()}>
                    로그인
                </div>
                <div className="maintain_status_wrap">
                    <div id="maintain_status" className={(active_status == true) ? "active" : null} onClick={()=>set_active_status(!active_status)}>
                        <div className="icon"></div>
                        <p>로그인 상태 유지하기</p>
                    </div>
                </div>
                <div className="sub_menu">
                    <div className="find_id">아이디 찾기</div>
                    <div className="find_pw">비밀번호 찾기</div>
                    <div className="join_membership">회원가입</div>
                </div>
            </div>
            <div className="platform_login">
                <div className="Naver">
                    네이버 로그인
                    <div className="image">
                        <img src="https://i2.wp.com/bwithmag.com/wp-content/uploads/2018/06/2%E1%84%82%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%87%E1%85%A5-N-%E1%84%85%E1%85%A9%E1%84%80%E1%85%A9.jpg?fit=526%2C527"></img>
                    </div>
                </div>
                <div className="FaceBook">
                    페이스북 로그인
                    <div className="image">
                        <img src="https://t1.daumcdn.net/cfile/tistory/994EAB4F5D2565432F"></img>
                    </div>
                </div>
                <div className="Kakatalk">
                    카카오톡 로그인
                    <div className="image">
                        <img src="https://t1.daumcdn.net/cfile/tistory/99792D425D0895002A"></img>
                    </div>
                </div>

            </div>
            
        </div>
    )
}

export default User_Login_Screen;