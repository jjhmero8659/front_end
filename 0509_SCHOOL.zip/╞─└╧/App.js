import React,{Component} from "react";
import axios from "axios"
import "./App.css";
import {BrowserRouter,Routes,Route,Link} from "react-router-dom";
import queryString from "query-string";
import Home from "./components/Home/Home.js";
import Search from "./components/Search/Search.js";
import Search_Icon from "./components/Home/img/search_icon.png";
import Personal_Prodcut from "./components/Personal_product/Personal_product.js";
import Review_Board from "./components/Review_Board/Review_Board.js"
import Review_Board_detail from "./components/Review_Board_detail/Review_Board_detail.js"
import User_Login from "./components/User_Login/User_Login.js"
import User_LogOut from "./components/User_LogOut/User_LogOut.js"
import User_Login_Screen from "./components/User_Login_Screen/User_Login_Screen.js"
import Join_membership_screen from "./components/Join_membership_screen/Join_membership_screen.js"
import Create_review from "./components/Create_review/Create_review.js"

class App extends Component{
  constructor(props){
    super(props)

    this.state = {
      NoteBook : [
        {id : 7701 , name : "LG전자 그램 20년형 17인치 i5", image : "https://images.ajrepository.com/item_images/001111218/001111218L1.jpg" , price : 1560000,review:13,gpa : 4.8,iframe :"https://www.youtube.com/embed/hUCKW8YUkGM" , iframe2 :"https://www.youtube.com/embed/oUzRG2Mq9f0"},
        {id : 7702 ,name : "삼성전자 갤럭시북 플렉스 13인치 i5", image : "http://img.danawa.com/prod_img/500000/240/143/img/10143240_1.jpg?shrink=330:330&_v=20200309141444" , price : 1700000 ,review:8,gpa : 4.3,iframe :"https://www.youtube.com/embed/kvSckomk2zM"},
        {id : 7703 ,name : "LG전자 그램 20년형 14인치 i5", image : "http://photo3.enuri.info/data/images/service/middle/79110000/79110132.jpg" , price : 1130000 ,review:9,gpa : 4.4,iframe :"https://www.youtube.com/embed/oUzRG2Mq9f0"},
        {id : 7704 ,name : "삼성전자 갤럭시북 플렉스 13인치 i7", image : "http://img.danawa.com/prod_img/500000/574/946/img/12946574_1.jpg?shrink=330:330&_v=20210405131410" , price : 1800000 ,review:4,gpa : 4.2,iframe :"https://www.youtube.com/embed/S5k77vTzBjQ"},
        {id : 7705 ,name : "삼성전자 갤럭시북 이온 15인치 i5 MX250", image : "	https://img.danawa.com/prod_img/500000/740/102/img/10102740_1.jpg?_v=20200818154200" , price : 2560000,review:12,gpa : 4.1,iframe :"https://www.youtube.com/embed/NpTdUHjy-7E"},
        {id : 7706 ,name : "삼성전자 갤럭시북 플렉스 15인치 i5", image : "https://img.danawa.com/prod_img/500000/886/677/img/11677886_1.jpg?shrink=330:330&_v=20210923104544" , price : 1630000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/QmDBKJvstHk"},
        {id : 7707 ,name : "LG전자 그램19년형 15인치 i5", image : "https://img.danawa.com/prod_img/500000/635/920/img/6920635_1.jpg?shrink=330:330&_v=20200306140750" , price : 1670000 ,review:7,gpa : 3.4,iframe :"https://www.youtube.com/embed/rT7CfkbE-UQ"},
        {id : 7708 ,name : "LG전자 그램 20년형 15인치i5", image : "https://img.danawa.com/prod_img/500000/870/263/img/10263870_1.jpg?shrink=330:330&_v=20200406102004" , price : 1320000 ,review:8,gpa : 3.7,iframe :"https://www.youtube.com/embed/pz5CxHVBp4A"},
        {id : 7709 ,name : "삼성전자 노트북9 Always 19년형 15인치 i7 MX150", image : "https://img.danawa.com/prod_img/500000/539/980/img/6980539_1.jpg?shrink=330:330&_v=20200303143754" , price : 1140000 ,review:10,gpa : 2.8,iframe :"https://www.youtube.com/embed/iGX6lL2AkQk"},
        {id : 7710 ,name : "삼성전자 노트북9 Always 18년형 13인치 i7", image : "	https://img.danawa.com/prod_img/500000/200/785/img/4785200_1.jpg?shrink=330:330&_v=20171213143150" , price : 2090000 ,review:2,gpa : 4.3,iframe :"https://www.youtube.com/embed/fIveStZwysA"},
      ],
      TV : [
        {id : 7801 ,name : "LG전자 울트라 HD TV AI 65인치", image : "https://www.lge.co.kr/kr/images/tvs/md08043811/gallery/medium01.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7802 ,name : "삼성전자 The Sero 43인치", image : "	https://img.danawa.com/prod_img/500000/904/992/img/7992904_2.jpg?shrink=500:500&_v=20220118125503" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7803 ,name : "LG전자 올레드 갤러리 TV 55인치", image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuJeALu-ve71qVLlBvuEynX4OWk1f5VREF1A&usqp=CAU" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7804 ,name : "LG전자 올레드 AI 55인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/kc4RehKPUwyrnB62dx2qyf4HZtY=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200707/020510-VjVxLzcFKI.jpeg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7805 ,name : "삼성전자 QLED 4K 65인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/obwq3fSFwX3dup9GJfxku05UGEU=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200707/061620-OwLcJ4b0U9.jpeg" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
        {id : 7806 ,name : "삼성전자 The Serif 49인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/-iT2A1o2k4c5QfLOTKblw8pjIMU=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200707/080132-Vb9Uf3ijOl.jpeg" , price : 1660000 ,review:12,gpa : 4.2,iframe :"https://www.youtube.com/embed/rofMzCx_zFY"},
        {id : 7807 ,name : "삼성전자 QLED 4K 49인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/-J4MtEOE01RDau7iiv63y6aZ-xE=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200707/062641-YzHFD2NaOs.jpeg" , price : 710000 ,review:10,gpa : 4.3,iframe :"https://www.youtube.com/embed/SkvgxVvlyPo"},
        {id : 7808 ,name : "LG전자 울트라 HD TV AI 55인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/e7IoBn7rcAkTm4nrpIa-IpAOFXE=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200706/032614-pXfhXIhNp1.jpg" , price : 1100000 ,review:5,gpa : 2.8,iframe :"https://www.youtube.com/embed/A4xzVnM28o4"},
        {id : 7809 ,name : "LG전자 울트라 HD TV AI 75인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/5wEKuIxQkZ990wF9CrXyJIcrBw4=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200706/021541-tT8g1VhTPO.jpeg" , price : 1950000 ,review:2,gpa : 3.8,iframe :"https://www.youtube.com/embed/vvMVhZBbAg0"},
        {id : 7810 ,name : "삼성전자 Crystal UHD 55인치", image : "https://d3jfjcd8dl9mjz.cloudfront.net/odoU341r5eSjQPsWdlZEpeciSyU=/200x200/s3.ap-northeast-2.amazonaws.com/ggulreview-uploads/images/any/200706/080448-Ef5jPCi7BE.jpeg" , price : 750000 ,review:7,gpa : 4.0,iframe :"https://www.youtube.com/embed/jQyVtn0rXaw"},
      ],
      Air_conditioner : [
        {id : 7901 ,name : "삼성 전자 무풍 에어컨", image : "https://www.samsungsales.co.kr/images/event/sales/ev_m_aircon_202009_01.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7902 ,name : "LG전자 휘센 듀얼 스페셜 17+7평", image : "https://www.lge.co.kr/kr/images/air-conditioners/md08045299/gallery/medium01.jpg" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7903 ,name : "삼성전자 무풍에어컨 무풍갤러리 19+6평 20년형", image : "https://yanolja001.godohosting.com/data/base/goods/big/AF17TX772FFRS_img.jpg" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7904 ,name : "LG전자 휘센 듀얼 프리미엄 20+7평", image : "https://www.lge.co.kr/kr/images/air-conditioners/md08045255/gallery/medium01.jpg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7905 ,name : "LG전자 휘센 듀얼 17평", image : "http://m.kemsystem.co.kr/web/product/big/202009/2321d4b884f14455fddd53849e712ed6.jpg" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
        
      ],
      Washing_machine : [
        {id : 7801 ,name : "LG전자 트롬 21kg", image : "https://www.lge.co.kr/kr/images/washing-machines/md08917869/gallery/medium01.jpg" , price : 1240000 ,review:4,gpa : 4.8,iframe :"https://www.youtube.com/embed/lul44Eva0LQ"},
        {id : 7802 ,name : "LG전자 트롬 17kg", image : "http://img.danawa.com/prod_img/500000/766/022/img/15022766_1.jpg?shrink=330:330&_v=20220420174443" , price : 1500000 ,review:5,gpa : 4.9,iframe :"https://www.youtube.com/embed/1E1gEApdpOY"},
        {id : 7803 ,name : "LG전자 트롬 14kg", image : "http://img.danawa.com/prod_img/500000/939/996/img/5996939_1.jpg?shrink=330:330&_v=20220119174810" , price : 2530000 ,review:7,gpa : 4.4,iframe :"https://www.youtube.com/embed/-ufR2b5Xa44"},
        {id : 7804 ,name : "LG전자 통돌이 14kg", image : "http://th3.tmon.kr/thumbs/image/7c4/85d/639/9445045e0_700x700_95_FIT.jpg" , price : 1840000 ,review:3,gpa : 3.8,iframe :"https://www.youtube.com/embed/0rpRkNoyEao"},
        {id : 7805 ,name : "삼성전자 워블 16kg", image : "http://img.danawa.com/prod_img/500000/042/536/img/12536042_1.jpg?shrink=330:330&_v=20201027171648" , price : 2260000 ,review:13,gpa : 4.1,iframe :"https://www.youtube.com/embed/hYFoty1PTgg"},
      ],

      view : "NoteBook",
    }
  }
  searchBook = () => {
    // window.location.href = "/personal_prodcut?product_id="+props.data.id+"&view="+view;
  }
  update_view = (data) => {
    this.setState({
      view : data
    })
  }

  jump_home = () => {
    window.location.href = "/";
  }

 componentDidMount(){
  // const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
  // console.log("/ queryObj :" ,queryObj.Login) //해당하는 물건의 이름
  // if(queryObj.Login == "true"){
  //   this.setState({
  //     Login : true,
  //     User_name : queryObj.Name,
  //   })
  // }
 }

  render(){

    if(window.sessionStorage.getItem("user_name") === null || window.sessionStorage.getItem("user_name") === "null"){
      var login = <User_Login

       />
    }
    else{
      var login = <User_LogOut
            
              />
    }
      return(
        <div id="App_wrap">
          
          <BrowserRouter>
              <div className="Logo" onClick={()=>this.jump_home()}>
                Logo
              </div>
              <div className="Search_product">
                  <input className="Search" placeholder="제품명 혹은 모델 명으로 검색하세요"></input>
                  <div className="Search_icon">
                      <img src={Search_Icon} onClick={this.searchBook}></img>
                  </div>
              </div>
  
              {login}
            <Routes>
  
                <Route exact path="/" element={<Home
                  NoteBook = {this.state.NoteBook}
                  TV = {this.state.TV}
                  Air_conditioner = {this.state.Air_conditioner}
                  Washing_machine = {this.state.Washing_machine}
                  update_view = {this.update_view}
                />}/>
  
                <Route path="/search" element={<Search
    
                />}/>
  
                <Route path="/personal_prodcut" element={<Personal_Prodcut //가전제품
                  view = {this.state.view}
                />}/>
  
                <Route path="/review_board" element={<Review_Board //가전제품
                />}/>
  
                <Route path="/review_board/detail" element={<Review_Board_detail //가전제품
                />}/>
  
                <Route path="/User_login" element={<User_Login_Screen //가전제품
                />}/>

                <Route path="/join_membership" element={<Join_membership_screen //가전제품
                />}/>

                <Route path="/create_review" element={<Create_review //가전제품
                />}/>
            </Routes>
  
            
          </BrowserRouter>
        </div>
      )
    
    
      // return(
      //   <div id="App_wrap">
          
      //     <BrowserRouter>
      //         <div className="Search_product">
      //             <input className="Search" placeholder="제품명 혹은 모델 명으로 검색하세요"></input>
      //             <div className="Search_icon">
      //                 <img src={Search_Icon} onClick={this.searchBook}></img>
      //             </div>
      //         </div>
  
      //         <User_LogOut
      //             Login_status = {this.state.Login}
      //         />
      //       <Routes>
  
      //           <Route exact path="/" element={<Home
      //             NoteBook = {this.state.NoteBook}
      //             TV = {this.state.TV}
      //             update_view = {this.update_view}
      //           />}/>
  
      //           <Route path="/search" element={<Search
    
      //           />}/>
  
      //           <Route path="/personal_prodcut" element={<Personal_Prodcut //가전제품
      //             view = {this.state.view}
      //           />}/>
  
      //           <Route path="/review_board" element={<Review_Board //가전제품
      //           />}/>
  
      //           <Route path="/review_board/detail" element={<Review_Board_detail //가전제품
      //           />}/>
  
      //           <Route path="/User_login" element={<User_Login_Screen //가전제품
      //           />}/>
      //       </Routes>
  
      //       <footer>
      //         <div className="footer_info">
      //           <p>
      //           최고의 전자제품 선택
      //           </p>
      //           <p>
      //           팀명 UEPR | 팀장 윤창호  팀원 김재담 최낙현 장준혁 | 개인정보보호책임자 *** | 사업자등록번호 ***-***-***
      //           경상북도 경산시 대학로 280 (영남대학교) | 이메일 wkd86591@naver.com
      //           </p>
      //           <p>
      //           의견/문의
      //           wkd86591@naver.com
      //           </p>
      //         </div>
      //       </footer>
      //     </BrowserRouter>
      //   </div>
      // )
    
    }
  }
    


export default App;