const express = require("express")	//express 요청

	const app = express()		//express 요청 값 저장

	const PORT = process.env.PORT || 4000; //PORT 번호 저장 , PORT번호는 4000번 또는 자동
    const db = require('./database/db.js')

    const bodyParser = require("body-parser")
    app.use(bodyParser.json());

    app.get('/api/get/get_product:product_id&:view',(req,res)=>{
        // console.log(req.params)
        db.query(`select * from ${req.params.view} where id="${req.params.product_id}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({Product:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get/get_review:product_id',(req,res)=>{ //해당 제품 리뷰 검색
        db.query(`select * from ${req.params.product_id}_review Limit 3`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                res.send({Review:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get_review/get_review_all:product_id',(req,res)=>{ //해당 제품 리뷰 검색
        // console.log("/api/get/get_review_all:product_id")
        db.query(`select * from ${req.params.product_id}_review`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                res.send({Review:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get_review_person/get_review:product_id&:writer',(req,res)=>{ //해당 제품 리뷰 검색
        // console.log("/api/get/get_review_all:product_id")
        db.query(`select * from ${req.params.product_id}_review where name="${req.params.writer}"`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                res.send({Review:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/check/user_login:id&:pw',(req,res)=>{ //해당 제품 리뷰 검색
        // console.log(`SELECT * FROM user_info WHERE id="${req.params.id}" AND passwd="${req.params.pw}"`)
        db.query(`SELECT * FROM user_info WHERE id="${req.params.id}" AND passwd="${req.params.pw}"`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                res.send({User_info:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.put('/api/put/modify_summary:id&:summary&:name&:title',(req,res)=>{ //해당 제품 리뷰 검색
        console.log(`update ${req.params.id}_review set summary="${req.params.summary}" where name="${req.params.name}" and title="${req.params.title}"`)
        db.query(`update ${req.params.id}_review set summary="${req.params.summary}" where name="${req.params.name}" and title="${req.params.title}"`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                // res.send({User_info:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get_represent/get_product',(req,res)=>{
        // console.log(req.params)
        db.query(`select * from represent`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({data:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })
    
    app.post('/api/post/join_membership',(req,res)=>{ //해당 제품 리뷰 검색
        db.query(`insert into user_info values("${req.body.name}","${req.body.id}","${req.body.passwd}","${req.body.gender}")`,(err,data)=>{
            // console.log("/api/get/get_review:product_id")
            if(!err){//오류없을때
                // console.log(data)
                // res.send({User_info:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.post('/api/post_/create_review',(req,res)=>{ //해당 제품 리뷰 검색
        title = req.body.title
        id = req.body.id
        summary = req.body.summary
        date = req.body.date
        inquiry = req.body.inquiry
        good_rec = req.body.good_rec
        name = req.body.name
        console.log(`insert into ${id}_review (title,summary,date,inquiry,good_rec,bad_rec,name) values("${title}","${summary}","${date}",0,0,0,"${name}")`);
        // db.query(`insert into user_info values("${req.body.name}","${req.body.id}","${req.body.passwd}","${req.body.gender}")`,(err,data)=>{
        //     // console.log("/api/get/get_review:product_id")
        //     if(!err){//오류없을때
        //         // console.log(data)
        //         // res.send({User_info:data})
        //         //res.send({hello:'hello response'})
        //         //response.send
        //         //서버의 응답인데,App로 넘어간다.
        //     }else{//오류가있으면
        //         console.log(err)
        //     }
        // })
    })

	app.listen(PORT, ()=>{ //포트 listen
    		console.log(`Server On:http://localhost: ${PORT}`)
	})