import React , {useEffect, useState} from "react";
import "./css/Slick_buy_model.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


function Slick_buy_model(props){

    const [background , set_background] = useState("")

    const settings = {
        // fade : true,
        dots: false,
        autoplay:false,
        infinite: true,
        speed: 1000,
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };

    console.log("buy_model_slick",props)

    useEffect(()=>{
        if(props.model == "first" && props.sys_Ty == "first" && props.size == "first"){
            set_background("black")
        }
    },[props.color])

    

    return(
        <div id="Slick_buy_model_wrap" className={background != "" ? background : null}>
            <Slider {...settings}>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff1.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff2.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff3.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff4.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff5.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/Slick_buy_product/fff/fff6.jpg"></img>
                        </div>
            </Slider>
        </div>
    )
}

export default Slick_buy_model;