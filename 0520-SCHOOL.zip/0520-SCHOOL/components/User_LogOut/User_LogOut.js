import React , {useEffect, useState} from "react";
import "./css/User_LogOut.css";
import $ from "jquery"; 


function User_LogOut(props){

    // console.log("Log_out",props)
    useEffect(()=>{
        $(function(){
            $("#User_LogOut_wrap").hover(
                function(e){
                    e.stopImmediatePropagation();
                    $(".User_sub").stop().slideToggle(200)
                }
            )
        })
    })

    const user_logOut = () => {
        window.sessionStorage.setItem("user_name",null);
        window.sessionStorage.setItem("user_id",null);
        window.sessionStorage.setItem("user_pw",null);

        window.location.href = "/";
    }

    return(
        <div id="User_LogOut_wrap">
               <a href="#" >{window.sessionStorage.getItem("user_name")} 님</a>
               <ul className="User_sub">
                   <li><a href="#">마이페이지</a></li>
                   <li><a href="#" onClick={()=>user_logOut()}>로그아웃</a></li>
               </ul>
        </div>
    )
    
    
}

export default User_LogOut;