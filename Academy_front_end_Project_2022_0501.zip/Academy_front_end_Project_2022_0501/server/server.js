const express = require("express")	//express 요청

	const app = express()		//express 요청 값 저장

	const PORT = process.env.PORT || 4000; //PORT 번호 저장 , PORT번호는 4000번 또는 자동

    const db = require("./database/db.js");

    app.get('/api/get/now_movie',(req,res)=>{
        // console.log('/api/get/personAll')
        db.query("select * from Now_Movie",(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({Movie_now:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get/detail_movie:id',(req,res)=>{
        db.query(`select * from Now_Movie where id="${req.params.id}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({Movie_Detail:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get/movie_board:id',(req,res)=>{
        db.query(`select * from ${req.params.id}_board`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({Board_list:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get/user_review:id&:writer',(req,res)=>{
        db.query(`select * from ${req.params.id}_board where writer="${req.params.writer}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({user_review:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get('/api/get_user_login/user_info:user_id&:user_pw',(req,res)=>{
        console.log(`select * from user_login where id="${req.params.user_id}" and pw="${req.params.user_pw}"`)
        db.query(`select * from user_login where id="${req.params.user_id}" and passwd="${req.params.user_pw}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({data:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                // console.log(err)
            }
        })
    })

    app.put('/api/modify/modify_summary:movie_id&:modify_summary&:title&:writer',(req,res)=>{
        console.log(req.params)
        console.log(`update ${req.params.movie_id}_board set summary="${req.params.modify_summary}" where title="${req.params.title}" and writer="${req.params.writer}"`)
        db.query(`update ${req.params.movie_id}_board set summary="${req.params.modify_summary}" where title="${req.params.title}" and writer="${req.params.writer}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                // res.send({data:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

    app.get(`/api/search/get_id:search_text`,(req,res)=>{
        // console.log(`select id from now_movie where name="${req.params.search_text}"`)
        db.query(`select id from now_movie where name="${req.params.search_text}"`,(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({data:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })

	app.get('/api/get_tobe/tobe_movie',(req,res)=>{
        // console.log('/api/get/personAll')
        db.query("select * from tobe_movie",(err,data)=>{
            if(!err){//오류없을때
                // console.log(data)
                res.send({Movie_tobe:data})
                //res.send({hello:'hello response'})
                //response.send
                //서버의 응답인데,App로 넘어간다.
            }else{//오류가있으면
                console.log(err)
            }
        })
    })
    
    
    
    
    app.listen(PORT, ()=>{ //포트 listen
    		console.log(`Server On:http://localhost: ${PORT}`)
	})