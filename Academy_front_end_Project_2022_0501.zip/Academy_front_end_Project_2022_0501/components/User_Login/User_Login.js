import React, {useState,useEffect} from "react";
import "./css/User_Login.css";
import queryString from "query-string";


function User_Login(){

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log(queryObj)
    },[])

    const jump_login = () => {
        window.location.href = "/User_login";
    }

	return(
		<div id="User_Login_wrap" onClick={()=>jump_login()}>
            User_Login
		</div>
	)
}

export default User_Login;