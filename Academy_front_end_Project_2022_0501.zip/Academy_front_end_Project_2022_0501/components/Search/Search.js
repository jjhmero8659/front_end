import React, {useState,useEffect} from "react";
import "./css/Search.css";
import queryString from "query-string";


function Search(){

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log(queryObj)
    },[])

	return(
		<div id="Search_wrap">
            search
		</div>
	)
}

export default Search;