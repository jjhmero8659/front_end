import axios from "axios";
import React, {useState,useEffect} from "react";
import "./css/User_review.css";


function User_review(props){
    console.log("USER",props)
    const [Modify_status,set_modify_status] = useState(false);
    const [Modify_summary,set_Modify_summary] = useState("");

    useEffect(()=>{
        console.log("props.summary!!",props.summary)
        set_Modify_summary(props.summary)
    },[])

    const click_modify = () => {
        if(sessionStorage.getItem('user_name') == "Admin" || sessionStorage.getItem('user_name') == props.writer){
            set_modify_status(!Modify_status)
        }
        else{
            alert("관리자 또는 해당 글 작성자만 수정이 가능합니다.");
        }
    }

    const click_modify_complete = () => {
        props.update_summary(Modify_summary);
        set_modify_status(!Modify_status);
    }

    const modify_summary = (e) => {
        set_Modify_summary(e.target.value)
    }

    if(Modify_status == false){
        
        return(
            <div id="User_review_wrap">
                <header>
                    <div className="title">
                        <div className="title_head">
                            제목
                        </div>
                        <div className="title_text">
                            {props.title}
                        </div>
                    </div>
                    <div className="sub_info">
                        <div className="writer_head">
                            작성자
                        </div>
                        <div className="writer_text">
                            {props.writer}
                        </div>
                        <div className="date_head">
                            등록일
                        </div>
                        <div className="date_text">
                            {props.date}
                        </div>
                        <div className="inquiry_head">
                            조회
                        </div>
                        <div className="inquiry_text">
                            {props.inquiry}
                        </div>
                    </div>
                </header>
                <div className="summary">
                    {Modify_summary}
                </div>
                <div className="Modify" onClick={()=>click_modify()}>
                    수정하기
                </div>
            </div>
        )
    }
    else{
        return(
            <div id="User_review_wrap">
                <header>
                    <div className="title">
                        <div className="title_head">
                            제목
                        </div>
                        <div className="title_text">
                            {props.title}
                        </div>
                    </div>
                    <div className="sub_info">
                        <div className="writer_head">
                            작성자
                        </div>
                        <div className="writer_text">
                            {props.writer}
                        </div>
                        <div className="date_head">
                            등록일
                        </div>
                        <div className="date_text">
                            {props.date}
                        </div>
                        <div className="inquiry_head">
                            조회
                        </div>
                        <div className="inquiry_text">
                            {props.inquiry}
                        </div>
                    </div>
                </header>
                <div className="summary">
                    <textarea  className="Modify_summary" type="text" defaultValue={Modify_summary} onChange={(e)=>modify_summary(e)}></textarea >
                </div>
                <div className="Modify_complete" onClick={()=>click_modify_complete()}>
                    저장하기
                </div>
            </div>
        )
    }
	
}

export default User_review;