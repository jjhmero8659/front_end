import {BrowserRouter,Routes,Route} from "react-router-dom";
import React, {useState,useEffect} from "react";
import Home from "./components/Home/Home.js";
import Search from "./components/Search/Search.js";
import Detail_Movie from "./components/Detail_Movie/Detail_Movie.js";
import Detail_Board from "./components/Detail_Board/Detail_Board.js";
import User_Login from "./components/User_Login/User_Login.js";
import User_Logout from "./components/User_Logout/User_Logout.js";
import User_login_screen from "./components/User_login_screen/User_login_screen.js";
import "./App.css";
import axios from "axios";

function App(){

  const [Searchtext, Set_Searchtext] = useState("");
  const [Login_status, Set_Login_status] = useState("false");
  const [movie_id,set_movie_id] = useState("")

  const search_btn = async() => {
    const res = await axios.get(`/api/search/get_id${Searchtext}`)
    set_movie_id(res.data.data[0].id);
    // window.location.href = "/movie_detail?Movie_name="+Searchtext+"&id="+props.id;



    
  }

  useEffect(()=>{
    if(movie_id != ""){
      window.location.href = "/movie_detail?Movie_name="+Searchtext+"&id="+movie_id;
    }
    else if(movie_id == ""){

    }
    else{

    }
  },[movie_id])


  const input_search = (e) => {
    Set_Searchtext(
      e.target.value
    )
  }

  useEffect(()=>{

    console.log("APPstorage_user_name",sessionStorage.getItem('user_name'));
  },[])

  const search_keypress = (e) => {
    if(e.code == "Enter"){
      search_btn();
    }
  }

  if(sessionStorage.getItem('user_name') == null || sessionStorage.getItem('user_name') === "null"){
    var User_status = <User_Login />
  }
  else{
    var User_status = <User_Logout
        user_name = {sessionStorage.getItem('user_name')}
    />
  }

  return(


    <div id="App_wrap">
      
      <BrowserRouter>
          <div id="input_wrap">
              <input type="text" placeholder="검색어를 입력하세요" onChange={(e)=>input_search(e)} onKeyPress={(e)=>search_keypress(e)}></input>
              <button className="Search_btn" onClick={()=>search_btn()}>검색</button>
          </div>
          {User_status}
          <Routes>
              <Route exact path="/" element={<Home/>}/>
              <Route path="/search" element={<Search/>}/>
              <Route path="/movie_detail" element={<Detail_Movie/>}/>
              <Route path="/board_detail" element={<Detail_Board/>}/>
              <Route path="/User_login" element={<User_login_screen/>}/>
          </Routes>
        </BrowserRouter>
    </div>
  )
}

export default App;