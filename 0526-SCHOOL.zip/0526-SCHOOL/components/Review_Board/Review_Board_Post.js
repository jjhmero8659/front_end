import React , {useEffect, useState} from "react";
import "./css/Review_Board_Post.css";


function Review_Board_Post(props){
    // console.log("POST____",props)

    useEffect(()=>{
        
    },[])

    const jump_board_detail = () => {
        window.location.href = "/review_board/detail?pro_id="+props.pro_id+"&user_name="+props.data.name+"&title="+props.data.title+"&view="+props.view;
    }

    return(
        <div id="Review_Board_Post_wrap">
            <div className="num">
                {props.data.num}
            </div>
            <div className="title" onClick={()=>jump_board_detail()}>
                {props.data.title}
            </div>
            <div className="name">
                {props.data.name}
            </div>
            <div className="date">
                {props.data.date}
            </div>
            <div className="inquiry">
                {props.data.inquiry}
            </div>
        </div>
    )
}

export default Review_Board_Post;