import React, {Component} from "react";
import "../css/Posts.css";
import PagiNation from "./PagiNation";
import Post from "./Post";
import $ from "jquery";

class Posts extends Component{
    constructor(props){
        super(props)

        this.state = {
            Current_page : 1,
            Page_per_page : 6,
        }
    }

    componentDidMount(){
        
    }

    slice_product_list = (product) => {
        var slice_product = [];

        var indexOfLast = this.state.Current_page * this.state.Page_per_page;
        var indexOfFirst = indexOfLast - this.state.Page_per_page;

        slice_product = product.slice(indexOfFirst,indexOfLast);
        return slice_product;
    }

    update_current_page = (data) => {
        this.setState({
            Current_page : data
        })
    }

    render(){
        // console.log("POSTS_VIEW",this.props.view)
        var post = this.slice_product_list(this.props.Product).map(
            (data,index) => (<Post
                key={index}
                data={data}
                view = {this.props.view}
            />)
        )

        return(
            <div id="Posts_wrap">
                    {post}
                    <PagiNation
                        total_length = {this.props.Product.length}
                        Current_page = {this.state.Current_page}
                        Page_per_page = {this.state.Page_per_page}
                        update_current_page = {this.update_current_page}
                    />

            </div>
        )
    }
}

export default Posts;