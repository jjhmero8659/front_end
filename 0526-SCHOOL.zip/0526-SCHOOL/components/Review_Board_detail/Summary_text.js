import React , {useEffect, useState} from "react";
import "./css/Summary_text.css";
import queryString from "query-string";
import axios from "axios";
import { data } from "jquery";

function Summary_text(props){

    const [pro_id,set_pro_id] = useState("");
    const [modify,set_modify] = useState(false);
    const [summary,set_summary] = useState(props.bagic_summary);

    // console.log("qwdoijqwdojiknh",props) 

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log("Summary_queryObj",queryObj)
        console.log("Summary_props",props)
        set_pro_id(queryObj.pro_id)

    },[])  

    const click_btn = () => {
        if(window.sessionStorage.getItem("user_name") == props.name || window.sessionStorage.getItem("user_name") == "Admin"){
            set_modify(!modify)
        }
        else{
            alert("관계자 또는 글작성자 만 수정이 가능합니다.")
        }
    }

    const modify_complete = () => {
        click_btn();
        props.modify_summary(summary)
    }

    const modify_summary = (e) => {
        set_summary(e.target.value);
    }

    const delete_review = async() => {
        var replace_title_ = props.data.title.replace(/ /g,"_");
        var replace_date_ = props.data.date.replace(/-/g,"_");

        alert("글 삭제가 완료 되었습니다."); //db삭제 구축 해야함
        window.location.href = "/review_board?pro_id="+props.pro_id+"&view="+props.view;
        // var Obj = {
        //     title : props.data.title,
        //     replace_title : replace_title_,
        //     id : pro_id,
        //     date : props.data.date,
        //     replace_date : replace_date_,
        //     good_rec : props.data.good_rec,
        //     bad_rec : props.data.bad_rec,
        //     name : window.sessionStorage.getItem("user_name"),
        // }
        const res = await axios.delete(`/api/delete_review`,{
            data: { // 서버에서 req.body.{} 로 확인할 수 있다.
                title : props.data.title,
                replace_title : replace_title_,
                id : pro_id,
                summary : props.data.summary,
                date : props.data.date,
                replace_date : replace_date_,
                good_rec : props.data.good_rec,
                bad_rec : props.data.bad_rec,
                name : window.sessionStorage.getItem("user_name"),
            },
            withCredentials: true,
          }
        ) 
    }

    if(modify === false){
        return(
            <div id="Summary_text_wrap">
                <div className="text">
                    {props.summary_text}
                </div>
                <div className="modify_before" onClick={()=>click_btn()}>글 수정</div>
            </div>
        )
    }
    else{
        return(
            <div id="Summary_text_wrap">
                <div className="text">
                    <textarea className="modify_summary" type="text" defaultValue={props.summary_text} onChange={(e)=>modify_summary(e)}></textarea>
                </div>
                <div className="modify_after" onClick={()=>modify_complete()}>글 저장</div>
                <div className="delete_review" onClick={()=>delete_review()}>글 삭제</div>
            </div>
        )
    }
}

export default Summary_text;