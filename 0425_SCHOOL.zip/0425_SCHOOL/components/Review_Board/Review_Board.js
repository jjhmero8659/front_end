import React , {useState} from "react";
import "./css/Review_Board.css";

function Review_Board(props){


    return(
        <div id="Review_Board_wrap">
            더보기 게시판 입니다.
            
        </div>
    )
}

export default Review_Board;