import React , {useEffect, useState} from "react";
import "./css/User_Login_Screen.css";


function User_Login_Screen(props){

    const [Login_status , set_Login_status] = useState(false)

    const check_log_info = () => {
        window.location.href="/?Login="+true;
    }

    // useEffect(()=>{
        
    // },[check_log_info()])



    return(
        <div id="User_Login_Screen_wrap">
            <div class="logo">
                전하다
            </div>
            <div className="Login">


                <div className="Login_btn" onClick={()=>check_log_info()}>
                    로그인
                </div>
            </div>

            
        </div>
    )
}

export default User_Login_Screen;