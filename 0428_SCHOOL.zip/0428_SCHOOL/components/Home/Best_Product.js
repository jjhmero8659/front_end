import React , {useState} from "react";
import "./css/Best_Product.css";

function Best_Product(props){

    const [Product,set_Product] = useState(props.Product)

    console.log("Best_pro" , Product)
    return(
        <div id="Best_Product_wrap">
            <div className="Best_Product_head">
                <p>
                    UEPR 이번달 가장 인기있는 제품
                </p>
            </div>
            <div className="back_ground">
                <div className="video">
                    <iframe width="500" height="315" src="https://www.youtube.com/embed/hUCKW8YUkGM" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                </div>
                
                <div className="right_side">
                    <div className="right_pro_head">
                        LG전자 그램 20년형 17인치 i5
                    </div>

                    <div className="Best_Product_text">

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Best_Product;