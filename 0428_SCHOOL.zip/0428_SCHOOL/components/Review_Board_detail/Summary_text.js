import React , {useEffect, useState} from "react";
import "./css/Summary_text.css";


function Summary_text(props){

    const [modify,set_modify] = useState(false);

    console.log("SUMARY_MODIFY", props)

    if(modify === false){
        return(
            <div id="Summary_text_wrap">
                {props.summary}
            </div>
        )
    }
    else{
        return(
            <div id="Summary_text_wrap">
            
            </div>
        )
    }
}

export default Summary_text;