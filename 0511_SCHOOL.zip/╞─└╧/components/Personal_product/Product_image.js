import React , {useEffect, useState} from "react";
import "./css/Product_image.css";
import $ from "jquery"


function Product_image(props){

    useEffect(()=>{
        var image1 = document.getElementById("pro_img1");
        var height_1 = image1.naturalHeight;
        var image2 = document.getElementById("pro_img2");
        var height_2 = image2.naturalHeight;
        var image3 = document.getElementById("pro_img3");
        var height_3 = image3.naturalHeight;
        
        
        // $(function(){
        //     $("#image1").css({"height":height_1})
        // })
        
    },[])

    console.log("IMAGE",props)
    return(
        <div id="Product_image_wrap">
            <div id="image1">
                <img id="pro_img1" src={props.image1}></img>
            </div>
            <div id="image2">
                <img id="pro_img2"  src={props.image2}></img>
            </div>
            <div id="image3">
            <img id="pro_img3" src={props.image3}></img>
                </div>
        </div>
    )
}

export default Product_image;