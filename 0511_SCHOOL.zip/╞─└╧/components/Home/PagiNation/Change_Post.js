import React, {Component} from "react";
import "../css/Change_Post.css";
import $ from "jquery"


class Change_Post extends Component{
    constructor(props){
        super(props)

        this.state = {
            
        }
    }

    componentDidMount(){
        $(function(){ 
            $(".Product_button").click(
                function(){
                    $(".Product_button").removeClass("active")
                    $(this).addClass("active")
                }
            )
        })
    }



    update_view = (data) => {
        this.props.update_view(data);
    }

    render(){
        return(
            <div id="Change_Post_wrap">
                <div id="NoteBook" className="Product_button active" onClick={()=>this.update_view("NoteBook")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        노트북
                    </a>
                </div>
                <div id="TV" className="Product_button" onClick={()=>this.update_view("TV")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        TV
                    </a>
                </div>
                <div id="Air_conditioner" className="Product_button" onClick={()=>this.update_view("Air_conditioner")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        에어컨
                    </a>
                </div>
                <div id="washing_machine" className="Product_button" onClick={()=>this.update_view("Washing_machine")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        세탁기
                    </a>
                </div>
                <div id="fan" className="Product_button" onClick={()=>this.update_view("fan")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        선풍기
                    </a>
                </div>
                <div id="Humidifier" className="Product_button" onClick={()=>this.update_view("Humidifier")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                       가습기
                    </a>
                </div>
                <div id="wireless_earphones" className="Product_button" onClick={()=>this.update_view("wireless_earphones")}>
                    <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        무선 이어폰
                    </a>
                </div>
                <div id="Air_purifier" className="Product_button" onClick={()=>this.update_view("Air_purifier")}>
                        <a href="#">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        공기 청정기
                    </a>
                </div>
            </div>
        )
    }
}

export default Change_Post;