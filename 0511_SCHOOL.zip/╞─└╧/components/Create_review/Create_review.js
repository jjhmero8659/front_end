import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/Create_review.css";
import queryString from "query-string";




function Create_review(props){

    const [product_id,set_id] = useState("");
    const [review_header , set_review_header] = useState("");
    const [review_summary , set_review_summary] = useState("");
    const [review_date , set_review_date] = useState("");
    const [review_inquiry , set_review_inquiry] = useState(0);
    const [review_good_rec , set_good_rec] = useState(0);
    const [review_num , set_review_num] = useState(0);

    
    const add_review = async() => {
        if(review_summary != "" && review_header != ""){
            var obj = {
                title : review_header,
                id : product_id,
                summary : review_summary,
                date : review_date,
                inquiry : review_inquiry,
                good_rec : review_good_rec,
                name : window.sessionStorage.getItem("user_name"),
                num : review_num,
            }
            window.location.href = "/review_board?pro_id="+product_id;
            const res = await axios.post(`/api/post_/create_review`,obj)
        }
        else{
            alert("입력되지 않은 내용이 있습니다.")
        }
    }

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        // console.log("Create_review!!" , queryObj.pro_id)
        // console.log("Create_review!!" , queryObj.post_num)

        set_id(queryObj.pro_id)
        set_review_num(Number(queryObj.post_num))

        let today = new Date();  
        let year = today.getFullYear(); // 년도
        let month = today.getMonth() + 1;  // 월
        let date = today.getDate();  // 날짜
        let day = today.getDay();  // 요일
        console.log(`${year}-0${month}-0${date}`)

        if(date < 10 && month < 10){
            set_review_date(`${year}-0${month}-0${date}`)
        }
        else if(date < 10){
            set_review_date(`${year}-${month}-0${date}`)
        }
        else if(month < 10){
            set_review_date(`${year}-0${month}-${date}`)
        }
        
    },[])


    return(
        <div id="Create_review_wrap">
            <div id="Review_Board_border">
                <div id="Review_Board_detail_wrap">
                    <div className="Review_title_wrap">
                        <p>제목</p>
                        <div className="Reivew_title">
                            <input type="text" placeholder="제목을 입력해주세요" onChange={(e)=>set_review_header(e.target.value)}></input>
                        </div>
                    </div>
                    <div className="Review_writer_wrap">
                        <p>작성자</p>
                        <div className="Reivew_writer">
                            {window.sessionStorage.getItem("user_name")}
                        </div>
                        <p>등록일</p>
                        <div className="Reivew_date">
                            {review_date}
                        </div>
                        <p>조회</p>
                        <div className="Reivew_inquiry">
                            {review_inquiry}
                        </div>
                        <p>추천 수</p>
                        <div className="Reivew_good_rec">
                            {review_good_rec}
                        </div>
                    </div>
                    <div className="Reivew_summary_wrap">
                        <div class="summary_header">
                            글 내용
                        </div>
                        <textarea className="create_summary_text" type="text" font-size="14px" onChange={(e)=>set_review_summary(e.target.value)}></textarea>
                    </div>
                    <div className="complete_btn" onClick={()=>add_review()}>
                        글 작성
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Create_review;