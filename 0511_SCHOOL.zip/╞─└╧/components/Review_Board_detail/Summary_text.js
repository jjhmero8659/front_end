import React , {useEffect, useState} from "react";
import "./css/Summary_text.css";
import queryString from "query-string";
import axios from "axios";

function Summary_text(props){

    const [pro_id,set_pro_id] = useState("");
    const [modify,set_modify] = useState(false);
    const [summary,set_summary] = useState(props.bagic_summary);

    // console.log("qwdoijqwdojiknh",props) 

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log("Summary_props",props)
        set_pro_id(queryObj.pro_id)

    },[])  

    const click_btn = () => {
        if(window.sessionStorage.getItem("user_name") == props.name || window.sessionStorage.getItem("user_name") == "Admin"){
            set_modify(!modify)
        }
        else{
            alert("관계자 또는 글작성자 만 수정이 가능합니다.")
        }
    }

    const modify_complete = () => {
        click_btn();
        props.modify_summary(summary)
    }

    const modify_summary = (e) => {
        set_summary(e.target.value);
    }

    const delete_review = async() => {
        alert("글 삭제가 완료 되었습니다."); //db삭제 구축 해야함
        window.location.href = "/review_board?pro_id="+props.pro_id;
        const res = await axios.delete(`/api/delete_review${pro_id}&${props.name}&${props.bagic_summary}`) 
        // DELETE FROM sandbox WHERE id=5;
    }

    if(modify === false){
        return(
            <div id="Summary_text_wrap">
                <div className="text">
                    {props.summary_text}
                </div>
                <div className="modify_before" onClick={()=>click_btn()}>글 수정</div>
            </div>
        )
    }
    else{
        return(
            <div id="Summary_text_wrap">
                <div className="text">
                    <textarea className="modify_summary" type="text" defaultValue={props.summary_text} onChange={(e)=>modify_summary(e)}></textarea>
                </div>
                <div className="modify_after" onClick={()=>modify_complete()}>글 저장</div>
                <div className="delete_review" onClick={()=>delete_review()}>글 삭제</div>
            </div>
        )
    }
}

export default Summary_text;