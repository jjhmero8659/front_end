import React , {Component} from "react";
import "./css/PrevArrow.css"
class PrevArrow extends Component{
    constructor(props){
        super(props);

        this.state={}
    }
    

    render(){
        return(
            <div className="PrevArrow_wrap">

            </div>
        )
    }
}

export default PrevArrow;