import React , {useEffect, useState} from "react";
import "./css/Search.css";


function Search(props){
    return(
        <div id="Search_wrap">
            
        </div>
    )
}

export default Search;