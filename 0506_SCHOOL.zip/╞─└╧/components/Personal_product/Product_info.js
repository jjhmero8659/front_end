import React , {Component} from "react";
import "./css/Product_info.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


class Product_info extends Component{
    constructor(props){
        super(props)

        this.state = {
            product : []
        }
    }

    componentDidMount(){
        this.setState({
            // product : this.props.product[0],
        })
    }


    render(){
        const settings = {
            // fade : true,
            dots: false,
            autoplay:true,
            infinite: true,
            speed: 1000,
            fade :true,
            arrows:false
        };
        // console.log("this.props.product[0]",this.state.product)
        // console.log("state",this.state.product)
        return(
            <div id="Product_info_wrap">
                <div className="Product_name">
                    {this.props.name}
                </div>
                <div className="Product_info_image">

                    <Slider {...settings}>
                        <div>
                            <img src={this.props.src}></img>
                        </div>
                        <div>
                            <img src={this.props.src2}></img>
                        </div>
                    </Slider>
                </div>
                <div className="Product_price">
                    제품 가격 : <span>{this.props.price}</span>  원
                </div>
                <div className="Product_gpa">
                    <img src="https://www.lottecinema.co.kr/NLCHS/Content/images/icon/star_14.png"></img><span>{this.props.gpa}</span>
                </div>
                <div className="Product_review">
                    제품 리뷰 : <span>7</span> 개
                </div>
            </div>
        )
    }
}

export default Product_info;