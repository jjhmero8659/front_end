import React , {useEffect, useState} from "react";
import "./css/Create_review.css";


function Create_review(props){

    const [review_header , set_review_header] = useState("");
    const [review_summary , set_review_summary] = useState("");
    const [review_date , set_review_date] = useState("");
    const [review_inquiry , set_review_inquiry] = useState(0);
    const [review_good_rec , set_good_rec] = useState(0);



    return(
        <div id="Create_review_wrap">
            <div id="Review_Board_border">
                <div id="Review_Board_detail_wrap">
                    <div className="Review_title_wrap">
                        <p>제목</p>
                        <div className="Reivew_title">
                            <input type="text" placeholder="제목을 입력해주세요" onChange={(e)=>set_review_header(e.target.value)}></input>
                        </div>
                    </div>
                    <div className="Review_writer_wrap">
                        <p>작성자</p>
                        <div className="Reivew_writer">
                            {window.sessionStorage.getItem("user_name")}
                        </div>
                        <p>등록일</p>
                        <div className="Reivew_date">
                            {review_date}
                        </div>
                        <p>조회</p>
                        <div className="Reivew_inquiry">
                            {review_inquiry}
                        </div>
                        <p>추천 수</p>
                        <div className="Reivew_good_rec">
                            {review_good_rec}
                        </div>
                    </div>
                    <div className="Reivew_summary_wrap">
                        <div class="summary_header">
                            글 내용
                        </div>
                        <textarea className="create_summary_text" type="text" font-size="14px" onChange={(e)=>set_review_summary(e.target.value)}></textarea>
                    </div>
                    <div className="complete_btn">
                        글 작성
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Create_review;