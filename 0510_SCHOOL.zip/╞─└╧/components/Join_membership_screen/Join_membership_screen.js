import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/Join_membership_screen.css";


function Join_membership_screen(props){

    const [input_id,set_id] =  useState("");
    const [input_pw,set_pw] =  useState("");
    const [input_check_pw,set_check_pw] =  useState("");
    const [input_name,set_name] =  useState("");
    const [input_age,set_age] =  useState(0);
    const [input_gender,set_gender] = useState("default");

    const checkPassword = () => {
        var regExp = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/

        return regExp.test(input_pw)
    }

    const check_name = () => {
        var regExp = /^[가-힣a-zA-Z]+$/

        return regExp.test(input_name)
    }

    const check_id = () => {
        var regExp = /^[A-Za-z]{1}[A-Za-z0-9]{3,19}$/

        return regExp.test(input_id)
    }

    const comparePassword = () => {
        if(input_pw == input_check_pw){
            return true;
        }
        return false
    }

    const check_info = async() => {
        let pass = true
        if(!check_id()){
            alert("아이디 입력 방식이 잘못되었습니다!")
            pass = false
        }
        if(!check_name()){
            alert("이름 입력 방식이 잘못되었습니다!")
            pass = false
        }
        if(!checkPassword()){
            alert("비밀번호 입력 방식이 잘못되었습니다!")
            pass = false
        }
        if(!comparePassword()){
            alert("비밀번호가 서로 다릅니다.")
            pass = false
        }
        if(input_gender == "default"){
            alert("성별을 선택해 주세요")
            pass = false
        }
        if(pass){
            alert("회원가입이 완료 되었습니다")
            var obj ={
                name : input_name,
                id : input_id,
                passwd : input_pw,
                gender : input_gender
            }
            const res = await axios.post('/api/post/join_membership',obj)
        }
    } 

    return(
        <div id="Join_membership_screen_wrap">
            <div className="input_wrap">
                
                <div className="id_wrap">
                    <p>아이디</p>
                    <input type="text" className="input_id" placeholder="4~20자리, 첫글자 숫자 X" onChange={(e)=>set_id(e.target.value)}></input>
                </div>

                <div className="pw_wrap">
                    <p>비밀번호</p>
                    <input type="password" className="input_pw" placeholder="최소 8자리, 숫자,문자,특수문자 최소 1개" onChange={(e)=>set_pw(e.target.value)}></input>
                </div>

                <div className="pw_check_wrap">
                    <p>비밀번호 재확인</p>
                    <input type="password" className="input_pw_check" onChange={(e)=>set_check_pw(e.target.value)}></input>
                </div>

                <div className="name_wrap">
                    <p>이름</p>
                    <input type="text" className="input_name" onChange={(e)=>set_name(e.target.value)}></input>
                </div>

                <div className="gender_wrap">
                    <p>성별</p>
                    <select className="gender_select" value={input_gender} onChange={(e)=>set_gender(e.target.value)}>
                        <option value="default" selected disabled hidden >미선택</option>
                        <option value="men">남자</option>
                        <option value="women">여자</option>
                    </select>
                </div>

                <div className="complete_btn" onClick={()=>check_info()}>
                    회원가입
                </div>
            </div>
        </div>
    )
}

export default Join_membership_screen;