import React , {Component} from "react";
import "./css/Product_info.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Platform from "./Platform.js"


class Product_info extends Component{
    constructor(props){
        super(props)

        this.state = {
            product : [],
            low_price : "",
        }
    }
    

    componentDidMount(){

        var slice_arr_str = []
            var slice_arr_num = []
            var min_price = "";

            
            slice_arr_str.push(this.props.data.haemil)
            slice_arr_str.push(this.props.data.wemake)
            slice_arr_str.push(this.props.data.interpark)
            slice_arr_str.push(this.props.data._11st)
            slice_arr_str.push(this.props.data.lotte)
            slice_arr_str.push(this.props.data.auction)
            slice_arr_str.push(this.props.data.gmarcket)


            if(slice_arr_str[0] != null){
                for(var i=0; i<slice_arr_str.length; i++){
                    for(var z=0; z<2; z++){
                        slice_arr_str[i] = slice_arr_str[i].replace(',','')
                    }
                    slice_arr_num.push(slice_arr_str[i])
                }
    
                min_price = Math.min.apply(null, slice_arr_num)+"";
                min_price = min_price.slice(0,min_price.length-6) + ',' + min_price.slice(min_price.length-6, min_price.length-3) + ',' + min_price.slice(min_price.length-3,min_price.length);
            }
            

        this.setState({
            low_price : min_price
            // product : this.props.product[0],
        })
    }


    render(){
        const settings = {
            // fade : true,
            dots: false,
            autoplay:true,
            infinite: true,
            speed: 1000,
            fade :true,
            arrows:false
        };
        // console.log("this.props.product[0]",this.state.product)
        // console.log("state",this.state.product)
        const price_floor_link = () => {
            alert("미구현 링크")
        }

        console.log("info!!!!",this.props.data)

    

        return(
            <div id="Product_info_wrap">
                <div className="Product_name">
                    {this.props.data.name}
                </div>
                <div className="Product_info_image">

                    <Slider {...settings}>
                        <div>
                            <img src={this.props.data.src}></img>
                        </div>
                        <div>
                            <img src={this.props.data.src2}></img>
                        </div>
                    </Slider>
                </div>
                {/* <div className="Product_price">
                    제품 가격 : <span>{this.props.price}</span>  원
                </div> */}
                <div className="Product_gpa">
                    <img src="https://www.lottecinema.co.kr/NLCHS/Content/images/icon/star_14.png"></img><span>{this.props.data.gpa}</span>
                </div>
                <div className="Product_review">
                    제품 리뷰 : <span>7</span> 개
                </div>
                <div className="price_floor_wrap">
                    <div className="price_floor">
                        <p className="title">최저가</p>
                        <p className="price">{this.state.low_price}</p>
                        <p className="title2">원</p>
                        <p className="link_price_floor" onClick={()=>price_floor_link()}>
                            최저가 사이트 로 이동
                        </p>
                    </div>
                    <div className="platform_wrap">
                        <Platform
                            data = {this.props.data}
                        />
                    </div>
                </div>
            </div>
        )
    }
}

export default Product_info;