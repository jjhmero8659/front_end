import React , {useEffect, useState} from "react";
import "./css/Review_Board_Posts.css";
import Review_Board_Post from "./Review_Board_Post.js";
import Review_Board_Posts_PagiNation from "./Review_Board_Posts_PagiNation.js";

function Review_Board_Posts(props){

    const [Current_page,set_Current_page] = useState(props.Current_page)
    const [Page_per_page,set_Page_per_page] = useState(props.Page_per_page)
    const [num,set_num] = useState(0)

    useEffect(()=>{
        set_num(props.num)
    },[])

    const slice_post = (data) => {
        var indexOfLast = Current_page * Page_per_page;
        var indexOfFirst = indexOfLast - Page_per_page;

        var slice_list = data.slice(indexOfFirst,indexOfLast);
        return slice_list;
    }

    const update_current = (data) => {
        set_Current_page(data)
    }

    const add_review = () => {
        if(window.sessionStorage.getItem("user_name") == null){
            alert("로그인 후 글 작성이 가능합니다!")
        }
        else{
            window.location.href="/create_review?pro_id="+props.pro_id+"&post_num="+(props.num+1);
        }
       
    }

    const review_post = slice_post(props.review).map(
        (data,index) => (
            <Review_Board_Post
                key = {index}
                data = {data}
                pro_id = {props.pro_id}
            />
        )
    )
    return(
        <div id="Review_Board_Posts_wrap">
            {review_post}
            <Review_Board_Posts_PagiNation
                total_length = {props.review.length}
                Current_page = {Current_page}
                Page_per_page = {Page_per_page}
                update_current = {update_current}
            />
            <div className="add_review" onClick={()=>add_review()}>글 작성</div>
        </div>
    )
}

export default Review_Board_Posts;