import React , {useEffect, useState} from "react";
import "./css/User_LogOut.css";
import $ from "jquery"; 


function User_LogOut(props){

    // console.log("Log_out",props)
    useEffect(()=>{
        $(function(){
            $("#User_LogOut_wrap").hover(
                function(e){
                    e.stopImmediatePropagation();
                    $(".User_sub").stop().slideToggle(200)
                }
            )
        })
    })

    return(
        <div id="User_LogOut_wrap">
               <a href="#" >{props.User_name} 님</a>
               <ul className="User_sub">
                   <li><a href="#">마이페이지</a></li>
                   <li><a href="#">로그아웃</a></li>
               </ul>
        </div>
    )
    
    
}

export default User_LogOut;