import React , {useEffect, useState} from "react";
import "./css/Join_membership_screen.css";


function Join_membership_screen(props){
    return(
        <div id="Join_membership_screen_wrap">
            <div className="input_wrap">
                <div className="id_wrap">
                    <p>아이디</p>
                    <input type="text" className="input_id"></input>
                </div>
                <div className="pw_wrap">
                    <p>비밀번호</p>
                    <input type="password" className="input_pw"></input>
                </div>
                <div className="pw_check_wrap">
                    <p>비밀번호 재확인</p>
                    <input type="password" className="input_pw_check"></input>
                </div>
                <div className="name_wrap">
                    <p>이름</p>
                    <input type="text" className="input_name"></input>
                </div>
                <div className="gender_wrap">
                    <p>성별</p>
                    
                    <select className="gender_select">
                        <option value="">남자</option>
                        <option value="">여자</option>
                        <option value="">상관없음</option>
                    </select>
                </div>
            </div>
        </div>
    )
}

export default Join_membership_screen;