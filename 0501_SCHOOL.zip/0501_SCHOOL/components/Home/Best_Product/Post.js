import React , {useEffect, useState} from "react";
import "./css/Post.css";
import axios from "axios";

function Post(props){

    console.log("Best_pro",props.data)

    return(
        <div id="BestProduct_Post_wrap">
            <div className="image">
                <img src={props.data.src}></img>
            </div>
            <div className="title">
                {props.data.title}
            </div>
        </div>
    )
}

export default Post;