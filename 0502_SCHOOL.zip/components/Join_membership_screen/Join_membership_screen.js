import React , {useEffect, useState} from "react";
import "./css/Join_membership_screen.css";


function Join_membership_screen(props){

    const [input_id,set_id] =  useState("");
    const [input_pw,set_pw] =  useState("");
    const [input_check_pw,set_check_pw] =  useState("");
    const [input_name,set_name] =  useState("");
    const [input_age,set_age] =  useState(0);
    const [input_gender,set_gender] = useState("default");

    const check_info = () => {
        if(input_name == "Admin"){
            alert("사용할 수 없는 이름 입니다.")
        }
        
    } 

    return(
        <div id="Join_membership_screen_wrap">
            <div className="input_wrap">
                <div className="id_wrap">
                    <p>아이디</p>
                    <input type="text" className="input_id" onChange={(e)=>set_id(e.target.value)}></input>
                </div>
                <div className="pw_wrap">
                    <p>비밀번호</p>
                    <input type="password" className="input_pw" onChange={(e)=>set_pw(e.target.value)}></input>
                </div>
                <div className="pw_check_wrap">
                    <p>비밀번호 재확인</p>
                    <input type="password" className="input_pw_check" onChange={(e)=>set_check_pw(e.target.value)}></input>
                </div>
                <div className="name_wrap">
                    <p>이름</p>
                    <input type="text" className="input_name" onChange={(e)=>set_name(e.target.value)}></input>
                </div>
                <div className="gender_wrap">
                    <p>성별</p>
                    <select className="gender_select" value={input_gender} onChange={(e)=>set_gender(e.target.value)}>
                        <option value="default" selected disabled hidden >미선택</option>
                        <option value="남자">남자</option>
                        <option value="여자">여자</option>
                    </select>
                </div>

                <div className="complete_btn" onClick={()=>check_info()}>
                    회원가입
                </div>
            </div>
        </div>
    )
}

export default Join_membership_screen;