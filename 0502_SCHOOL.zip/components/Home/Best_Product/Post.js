import React , {useEffect, useState} from "react";
import "./css/Post.css";
import axios from "axios";

function Post(props){

    console.log("Best_pro",props.data)

    return(
        <div id="BestProduct_Post_wrap">
            <div className="image">
                <img src={props.data.src}></img>
            </div>
            <div className="profile">

            </div>
            <div className="good_rec">
                추천수 : {props.data.good_rec}
            </div>
            <div className="gpa">
                <img src="https://www.lottecinema.co.kr/NLCHS/Content/images/icon/star_14.png"></img>
                <p>{props.data.gpa}</p>
            </div>
            <div className="title">
                {props.data.title}
            </div>

            <div className="writer">
                작성자
            </div>
            <div className="date">
                {props.data.date}
            </div>
        </div>
    )
}

export default Post;