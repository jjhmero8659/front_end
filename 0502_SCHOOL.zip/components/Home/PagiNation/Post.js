// import React, {Component} from "react";
import { useNavigate } from 'react-router';
import React, {useState} from "react";
import "../css/Post.css";

function Post(props){

    const[view,set_view] = useState(props.view);
    const detail_product = () => {
        window.location.href = "/personal_prodcut?product_id="+props.id+"&view="+view;
    }
    // console.log("POST : ", view)

    var iframe_src = props.iframe
    // console.log("iframe_src : ", iframe_src)
    return(
                    <div id="Post_wrap">
                        <div className="name" onClick={() => detail_product()}>
                            {props.name}
                        </div>
                        <div className="image" onClick={() => detail_product()}>
                            <img src={props.image}/>
                        </div>
                        <div className='iframe'>
                            <iframe width="400" height="180" src={iframe_src} title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                        </div>
                        <div className="price">
                            제품가격 : <span>{props.price}</span> 원
                        </div>
                        <div className="review">
                            사용자 후기 : <span>{props.review}</span> 개
                        </div>
                        <div className="gpa">
                            사용자 평점 : <span>{props.gpa}</span>
                        </div>
                        <div className='Post_text'>

                        </div>
                    </div>
    )
}

export default Post;




// class Post extends Component{
//     constructor(props){
//         super(props)

//         this.state = {

//         }
//     }
    
//     detail_product = () => {
//         // window.location.href = "/personal_prodcut?product_id="+this.props.id;
//         let navigate = useNavigate();
//         navigate("/personal_prodcut?product_id="+this.props.id)
        
//     }

//     render(){
//         console.log("post", this.props.id)
//         console.log("name", this.props.name)
//         return(
//             <div id="Post_wrap">
//                 <div className="name" onClick={this.detail_product}>
//                     {this.props.name}
//                 </div>
//                 <div className="image" onClick={this.detail_product}>
//                     <img src={this.props.image}/>
//                 </div>
//                 <div className="price">
//                     제품가격 : {this.props.price} 원
//                 </div>
//                 <div className="review">
//                     사용자 후기 : {this.props.review} 개
//                 </div>
//                 <div className="gpa">
//                     사용자 평점 : <span>{this.props.gpa}</span>
//                 </div>
//             </div>
//         )
//     }
// }

// export default Post;
