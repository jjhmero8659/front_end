import React , {useEffect, useState} from "react";
import "./css/Create_review.css";


function Create_review(props){
    return(
        <div id="Create_review_wrap">
            <div id="Review_Board_border">
                <div id="Review_Board_detail_wrap">
                    <div className="Review_title_wrap">
                        <p>제목</p>
                        <div className="Reivew_title">
                            <input type="text" placeholder="제목을 입력해주세요"></input>
                        </div>
                    </div>
                    <div className="Review_writer_wrap">
                        <p>작성자</p>
                        <div className="Reivew_writer">
                            {window.sessionStorage.getItem("user_name")}
                        </div>
                        <p>등록일</p>
                        <div className="Reivew_date">
                            2022-05-01
                        </div>
                        <p>조회</p>
                        <div className="Reivew_inquiry">
                            0
                        </div>
                        <p>추천 수</p>
                        <div className="Reivew_good_rec">
                            0
                        </div>
                    </div>
                    <div className="Reivew_summary_wrap">
                        <div class="summary_header">
                            글 내용
                        </div>
                        {/* <Summary_text
                            pro_id = {pro_id}
                            name = {review.name}
                            bagic_summary = {review.summary}
                            summary_text = {update_summary}
                            modify_summary = {modify_summary}
                        /> */}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Create_review;