import React, {Component} from "react";

class Posts extends Component{
    constructor(props){
        super(props)

        this.state = {

        }
    }

    render(){
        return(
            <div id="Posts_wrap">

            </div>
        )
    }
}

export default Posts;