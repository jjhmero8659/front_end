import React , {useEffect, useState} from "react";
import "./css/Galaxy_watch.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


function Galaxy_watch(props){

    const settings = {
        // fade : true,
        dots: false,
        autoplay:false,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };

    return(
        <div id="Galaxy_watch_wrap">
            <div className="top_img_timer">
                <img src="/img/Slide_Banner/galaxy_watch/banner_timer.png"></img>
            </div>

            <div className="buy_model">
                <p className="header_p">Galaxy Watch4 <i>I</i> Watch4 Classic</p>
                <h2>우리 가족 건강 관리는 갤럭시 워치로!</h2>

                <div className="slick_wrap">
                    <Slider {...settings}>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch1.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch2.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch3.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch4.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch5.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch6.jpg"></img>
                        </div>
                    </Slider>
                </div>
                <div className="right_side">
                    <div className="model">
                        <p>제품</p>
                        <div className="button_wrap">
                            <div className="left_button ">
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch.jpg"></img>
                                <p>갤럭시 워치4</p>
                            </div>

                            <div className="right_button ">
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch2.jpg"></img>
                                <p>갤럭시 워치4 클래식</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Galaxy_watch;