import React , {useEffect, useState} from "react";
import "./css/Platform.css";


function Platform(props){
    console.log("platform !!!!",props.data)

    

    return(
        <div id="Platform_wrap">
            <div className="Haemilpc">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/PLC48_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.haemil} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="Wemakeprice">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/TN729_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.wemake} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="Interpark">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/ED910_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.interpark} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="11st">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/TH201_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data._11st} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="Lotte">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/EE309_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.lotte} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="Auction">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/EE715_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.auction} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
            <div className="Gmarcket">
                <div className="logo_img">
                    <img src="http://img.danawa.com/cmpny_info/images/EE128_logo.gif"></img>
                </div>
                <div className="platform_price">
                    {props.data.gmarcket} 원
                </div>
                <div className="shipping">무료배송</div>
            </div>
        </div>
    )
}

export default Platform;