// import React , {Component} from "react";
// import "./css/Product_board.css";

// class Product_board extends Component{
//     constructor(props){
//         super(props)

//         this.state = {

//         }
//     }

//     render(){
//         return(
//             <div id="Product_board_wrap">

//             </div>
//         )
//     }
// }

// export default Product_board;


import React , {useState} from "react";
import Product_board_post from "./Product_board_post.js";
import "./css/Product_board.css";

function Product_board(props){

    const [review,setReview] = useState([])
    
    console.log(props.product_id)
    //   useEffect(() => {  // 리뷰 게시판 가져오기
    //     const res = await axios.get("/app/get/get_review"+props.product_id);
    //     setReview(
    //       res.data.Product
    //     )
    //   }, [])

    // const review_3 = review.map(
    //     (data) => (
    //         <Product_board_post
    //             num = {data.num}
    //             review = {data.review}
    //         />
    //     )
    // )

    return(
        <div id="Product_board_wrap">
            <div className="board_header">
                사용자 대표 리뷰
            </div>
        </div>
    )
}

export default Product_board;