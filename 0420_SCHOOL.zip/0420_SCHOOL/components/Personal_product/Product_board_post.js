import React , {useState} from "react";
import "./css/Product_board_post.css";

function Product_board_post(props){

    const [review,setReview] = useState([])

    return(
        <div id="Product_board_post_wrap">
            
        </div>
    )
}

export default Product_board_post;