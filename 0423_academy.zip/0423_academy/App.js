import {BrowserRouter,Routes,Route} from "react-router-dom";
import React, {useState} from "react";
import Home from "./components/Home/Home.js";
import Search from "./components/Search/Search.js";
import Detail_Movie from "./components/Detail_Movie/Detail_Movie.js";
import "./App.css";

function App(){

  const [Searchtext, Set_Searchtext] = useState("");

  const search_btn = (e) => {
    window.location.href = "/search?search_text="+Searchtext;
  }

  const input_search = (e) => {
    Set_Searchtext(
      e.target.value
    )
  }

  return(
    <div id="App_wrap">
      <BrowserRouter>
          <div id="input_wrap">
              <input type="text" placeholder="검색어를 입력하세요" onChange={(e)=>input_search(e)}></input>
              <button className="Search_btn" onClick={()=>search_btn()}>검색</button>
          </div>
          
          <Routes>
              <Route exact path="/" element={<Home/>}/>
              <Route path="/search" element={<Search/>}/>
              <Route path="/movie_detail" element={<Detail_Movie/>}/>
          </Routes>
        </BrowserRouter>
    </div>
  )
}

export default App;