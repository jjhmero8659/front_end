import React, {useState,useEffect} from "react";
import "./css/Detail_Movie.css";
import queryString from "query-string";
import axios from "axios";

function Detail_Movie(){

    const [id,set_id] = useState("");

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log("DEtail",queryObj.id)

        get_movie_detail(queryObj.id);
    },[])


    const get_movie_detail = async() => {
        const res = await axios.get('/api/get/detail_movie'+id);
    };

    return(
        <div id="Detail_Movie_wrap">
            
        </div>
    )
}

export default Detail_Movie;