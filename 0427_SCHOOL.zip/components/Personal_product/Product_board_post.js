import React , {useState} from "react";
import "./css/Product_board_post.css";
import User_img from "../Home/img/user_img.png";
import Like from "../Home/img/like_img.png";

function Product_board_post(props){
    console.log("BOARD",props)
    // const jump_board_page = () => {
    //     window.location.href = "/review_board?pro_id="+props.product_id;
    // }

    return(
        <div id="Product_board_post_wrap">
            <div className="user_img">
                <img src={props.user_img}></img>
            </div>
            <div className="name">
                {props.name}
            </div>
            <div className="title">
                {props.title}
            </div>
            <div className="review_img">
                <img src={props.review_img}></img>
            </div>
            <div className="time">
                18시간 전
            </div>
            <div className="good_rec_wrap">
                <div className="good_rec">
                    <img src={Like}></img>
                </div>
                <div className="good_rec_text">
                    {props.good_rec} 개
                </div>
            </div>

            <div className="bad_rec_wrap">
                <div className="bad_rec">
                    <img src={Like}></img>
                </div>
                <div className="bad_rec_text">
                    {props.bad_rec} 개
                </div>
            </div>
            
        </div>
    )
}

export default Product_board_post;