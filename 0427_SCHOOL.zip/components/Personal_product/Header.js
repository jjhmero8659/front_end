import React , {Component} from "react";
import "./css/Product_Header.css";


class Product_Header extends Component{
    constructor(props){
        super(props)

        this.state = {
        }
    }

    componentDidMount(){
    }


    render(){
        return(
            <div id="Product_Header_wrap">

            </div>
        )
    }
}

export default Product_Header;