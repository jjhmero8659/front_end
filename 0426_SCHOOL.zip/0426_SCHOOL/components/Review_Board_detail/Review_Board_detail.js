import React , {useEffect, useState} from "react";
import "./css/Review_Board_detail.css";
import queryString from "query-string";

function Review_Board_detail(props){

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
        console.log("queryObj :" ,queryObj.pro_id) //해당하는 물건의 이름

    },[])

    return(
        <div id="Review_Board_detail_wrap">
            
        </div>
    )
}

export default Review_Board_detail;