import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/User_Login_Screen.css";


function User_Login_Screen(props){

    // const [Login_status , set_Login_status] = useState(false)
    const [user_id,set_id] = useState("");
    const [user_pw,set_pw] = useState("");
    const [user_info,set_userinfo] = useState([]);

    const check_log_info = async() => {
        const res = await axios.get(`/api/check/user_login${user_id}&${user_pw}`);
        console.log(res.data.User_info.length)
        if(res.data.User_info.length == 0){
            alert("ID 또는 Password 가 틀렸습니다.")
        }
        else{
            window.location.href="/?Login="+true+"&Name="+res.data.User_info[0].name;
        }
        
        
    }

    const onchange_id = (e) => {
        set_id(e.target.value)
    }

    const onchange_pw = (e) => {
        set_pw(e.target.value)
    }

    // useEffect(()=>{
        
    // },[check_log_info()])



    return(
        <div id="User_Login_Screen_wrap">
            <div class="logo">
                LOGO
            </div>
            <div className="Login">
                <input className="input_id" type="text" placeholder="아이디 를 입력해주세요" onChange={(e)=>onchange_id(e)}></input>
                <input className="input_pw" type="password" placeholder="비밀번호 를 입력해주세요" onChange={(e)=>onchange_pw(e)}></input>
                <div className="Login_btn" onClick={()=>check_log_info()}>
                    로그인
                </div>
            </div>

            
        </div>
    )
}

export default User_Login_Screen;