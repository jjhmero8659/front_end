import React , {useEffect, useState} from "react";
import "./css/User_Login.css";


function User_Login(props){

    const [status,set_status] = useState(false)

    useEffect(()=>{
        set_status(props.Login_status)
    },[])

    const jump_Login_detail = () => {
        window.location.href = "/User_login";
    }

    const jump_join_membership_detail = () => {
        // window.location.href = "/User_login";
    }

    return(
        <div id="User_Login_wrap">
            <a href="#" onClick={()=>jump_Login_detail()}>로그인</a>
            <span> / </span>
            <a href="#" onClick={()=>jump_join_membership_detail()}>회원가입</a>
        </div>
    )

}

export default User_Login;