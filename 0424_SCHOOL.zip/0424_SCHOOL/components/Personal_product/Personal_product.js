import React , {Component, useEffect, useState} from "react";
import "./css/Personal_product.css";
import queryString from "query-string";
import axios from "axios";
import Header from "./Header.js";
import Product_info from "./Product_info.js";
import Product_spec from "./Product_spec.js";
import Product_board from "./Product_board.js";
import { useLocation } from "react-router";


// class Personal_prodcut extends Component{
//     constructor(props){
//         super(props)

//         this.state = {
//             product_id : "",
//             product : [],
//             view : this.props.view,
//         }
//     }

//     componentDidMount(){
//         const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
//         console.log("id" ,queryObj.product_id) //해당하는 물건의 이름
//         this.setState({
//             product_id : queryObj.product_id,
//         },function(){
//             this.get_product();
//         })
//     }

//     get_product = async() => {
//         const res = await axios.get("/api/get/get_product"+this.state.product_id);
//         console.log("db data" , res.data.Product)
//         this.setState({
//             product : res.data.Product
//         })
//     } 

//     render(){
//         const product_info = this.state.product.map(
//             (data,index) => (
//                 <Product_info
//                     key={index}
//                     name = {data.name}
//                     price = {data.price}
//                     review = {data.review}
//                     gpa = {data.gpa}
//                     src = {data.src}
//                 />
//             )
//         )
//         return(
//             <div id="Personal_product_wrap">
//                 <div className="header_Personal">
//                     <Header/>
//                 </div>
//                 <nav>
//                     {product_info}
//                     <Product_spec/>
//                     <Product_board
//                         product_id  = {this.state.product_id}
//                     />
//                 </nav>
//             </div>
//         )
//     }
// }

// export default Personal_prodcut;


function Personal_prodcut(props){

    const [product_id,set_product_id] = useState("")
    const [product,set_product] = useState([])
    const [view,set_view] = useState(props.view)
    const [review,setReview] = useState([])

    useEffect(() => {
        const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
        console.log("queryObj :" ,queryObj) //해당하는 물건의 이름
        console.log("queryObj_view :" ,queryObj.view)

        set_product_id(
            queryObj.product_id
        )
        set_view(
            queryObj.view
        )

    },[]);

    useEffect(()=>{
        if(product_id != ""){
            get_product(product_id)
            get_review3(product_id)
        }
    },[product_id])


    const get_product = async(data) => {
        const res = await axios.get(`/api/get/get_product${data}&${view}`);
        // console.log("db data" , res.data.Product)
        set_product(
            res.data.Product
        )
    }
    
    const get_review3 = async(data) => {
        const res = await axios.get(`/api/get/get_review${data}`);
        // console.log("get_review3" , res.data)
        setReview(
            res.data.Review
        )
    }

    const product_info = product.map(
                    (data,index) => (
                        <Product_info
                            key={index}
                            name = {data.name}
                            price = {data.price}
                            review = {data.review}
                            gpa = {data.gpa}
                            src = {data.src}
                        />
                    )
    )
    
    return(
                    <div id="Personal_product_wrap">
                        <div className="header_Personal">
                            <Header/>
                        </div>
                        <nav>
                            {product_info}
                            <Product_spec/>
                            <Product_board
                                product_id  = {product_id}
                                review = {review}
                            />
                        </nav>
                    </div>
                )
}
export default Personal_prodcut;