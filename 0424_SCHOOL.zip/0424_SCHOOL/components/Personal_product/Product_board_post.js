import React , {useState} from "react";
import "./css/Product_board_post.css";
import User_img from "../Home/img/user_img.png";
import Like from "../Home/img/like_img.png";

function Product_board_post(props){

    return(
        <div id="Product_board_post_wrap">
            <div className="user_img">
                <img src={User_img}></img>
            </div>
            <div className="name">
                {props.name}
            </div>
            <div className="review">
                {props.review}
            </div>
            <div className="good_rec_wrap">
                <div className="good_rec">
                    <img src={Like}></img>
                </div>
                <div className="good_rec_text">
                    {props.good_rec} 개
                </div>
            </div>

            <div className="bad_rec_wrap">
                <div className="bad_rec">
                    <img src={Like}></img>
                </div>
                <div className="bad_rec_text">
                    {props.bad_rec} 개
                </div>
            </div>
            
        </div>
    )
}

export default Product_board_post;