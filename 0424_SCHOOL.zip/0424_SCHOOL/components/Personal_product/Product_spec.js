import React , {Component} from "react";
import "./css/Product_spec.css";

class Product_spec extends Component{
    constructor(props){
        super(props)

        this.state = {

        }
    }

    render(){
        return(
            <div id="Product_spec_wrap">
                <div className="Product_spec_text">
                   상품 상세정보
                </div>
            </div>
        )
    }
}

export default Product_spec;