import React, {useState} from "react";
import "./css/Now_PagiNation.css";


function Now_PagiNation(props){
    var list = [];

    for(var i=1; i<=Math.ceil(props.total / props.Page_per_page); i++){
        list.push(i);
    }
    const icon_click = (data) => {
        props.update_current(data);
    }

    var page_icon = list.map(
        (data,index) => (
            <div key={index} className="page_icon" onClick={()=>icon_click(data)}>{data}</div>
        )
    )
	return(
		<div id="Now_PagiNation_wrap">
            {page_icon}
		</div>
	)
}

export default Now_PagiNation;