import React, {useState,useEffect,Component} from "react";
import "./css/Slick.css";
import queryString from "query-string";
import "slick-carousel/slick/slick.css" 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";



class Slick extends Component{
    constructor(props){
        super(props);
      }
      

    

    render(){
        const settings = { 
            fade:true,
            autoplay : true,
            dots: true, 
            infinite: true, 
            speed: 1000, 
            slidesToShow: 1, 
            slidesToScroll: 1 
        };
        return(
            <div id="Slick_wrap">
                <Slider {...settings}>
                    <div>
                        <img src="https://caching2.lottecinema.co.kr/lotte_image/2022/Doctor/0421/Doctor_1920420.jpg"/>
                    </div>
                    <div>
                        <img src="https://caching2.lottecinema.co.kr/lotte_image/2022/Bom/0426/Bom_1920420.jpg"/>
                    </div>
                    <div>
                        <img src="https://caching2.lottecinema.co.kr/lotte_image/2022/Da/Da_1920420.jpg"/>
                    </div>
                </Slider>
            </div>
        )
    }
}

export default Slick;