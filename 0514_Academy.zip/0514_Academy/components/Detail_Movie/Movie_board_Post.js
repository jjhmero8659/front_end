import React, {useState} from "react";
import "./css/Movie_board_Post.css";


function Movie_board_Post(props){
    const jump_board_detail = () => {
        window.location.href = "/board_detail?id="+props.id+"&writer="+props.data.writer;
    }
	return(
		<div id="Movie_board_Post_wrap">
            <div className="num">
                    {props.data.num}
                </div>
                <div className="title" onClick={()=>jump_board_detail()}>
                    {props.data.title}
                </div>
                <div className="writer">
                    {props.data.writer}    
                </div>
                <div className="date">
                    {props.data.date}
                </div>
                <div className="attach">
                    {props.data.attach}
                </div>
                <div className="inquiry">
                    {props.data.inquiry}
            </div>
		</div>
	)
}

export default Movie_board_Post;