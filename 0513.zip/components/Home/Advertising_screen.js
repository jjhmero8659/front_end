import React , {useEffect, useState} from "react";
import "./css/Advertising_screen.css";


function Advertising_screen(props){

    const [active,set_active] = useState(false);

    return(
        <div id="Advertising_screen_wrap" className={(active == true) ? "active" : null}>
            <div className="text1">
                최적의 가전제품 선택 리뷰
            </div>
            <div className="Logo">
                Logo
            </div>
            <div id="close_btn" onClick={()=>set_active(!active)}>

            </div>
            <div className="text_mobile">
                모바일앱으로 이용하시면 더욱 편리해요.
            </div>
            <div className="character_img">
                <img src="https://mblogthumb-phinf.pstatic.net/MjAxNzA2MDdfODIg/MDAxNDk2NzcwNDY1NzM5.gJsETNocmK44YijC1oAWlg7EedECxEABFVUmbUSYgtUg.avnFrph2fHIkHpNIKQ9cs1zcA76mWLKOCEXfX10ZxZwg.PNG.tryukjin/%EB%AF%B8%EB%8B%88%EC%96%B8%EC%A6%88_%EB%B0%B0%EA%B2%BD%ED%99%94%EB%A9%B4_%EC%BA%90%EB%A6%AD%ED%84%B0_%ED%95%B8%EB%93%9C%ED%8F%B0_%EB%B0%B0%EA%B2%BD%ED%99%94%EB%A9%B4_78%EB%B2%88%EC%A8%B0_%288%29.png?type=w2"></img>
            </div>
            <div className="mobile_icon">
                <div className="google">
                    <img src="https://ping2g.com/img/wing_btn01.png"></img>
                </div>
                <div className="apple">
                    <img src="https://ping2g.com/img/wing_btn02.png"></img>
                </div>
            </div>
        </div>
    )
}

export default Advertising_screen;