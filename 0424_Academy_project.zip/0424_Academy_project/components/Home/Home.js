import React, {useState,useEffect} from "react";
import "./css/Home.css";
import Now_PagiNation from "./Now_PagiNation.js";
import Now_Posts from "./Now_Posts.js";
import axios from "axios";

function Home(){

    const [Current_page,set_current] = useState(1)
    const [Page_per_page,set_Page_per_page] = useState(5)
    const [Now_Movie,set_now_movie] = useState([])

    useEffect(()=>{
        get_now_movie();
    },[])

    const get_now_movie = async() => {
        const res = await axios.get('/api/get/now_movie')
        set_now_movie(res.data.Movie_now)
    }

    const update_current = (data) => {
        set_current(
            data
        )
    }

	return(
		<div id="Home_wrap">
            <div className="Slick_wrap">

            </div>

            <div className="Now_page_wrap">
                <div className="head_text">
                    현재 상영 영화
                </div>
                <Now_Posts
                    Now_Movie = {Now_Movie}
                    Current_page = {Current_page}
                    Page_per_page = {Page_per_page}
                />
                <Now_PagiNation
                    total = {Now_Movie.length}
                    Current_page = {Current_page}
                    Page_per_page = {Page_per_page}
                    update_current = {update_current}
                />
            </div>

            <div className="Tobe_page_wrap">

            </div>
		</div>
	)
}

export default Home;