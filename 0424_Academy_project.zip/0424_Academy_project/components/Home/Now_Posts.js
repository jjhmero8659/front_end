import React, {useState} from "react";
import "./css/Now_Posts.css";
import Now_Post from "./Now_Post.js";


function Now_Posts(props){
    
    const slice_movie = (data) => {
        var indexOfLast = props.Current_page * props.Page_per_page;
        var indexOfFirst = indexOfLast - props.Page_per_page;

        var slice_list = data.slice(indexOfFirst,indexOfLast);
        return slice_list;
    }

    const slice_now = slice_movie(props.Now_Movie).map(
        (data,index) => (
            <Now_Post
                key={index}
                name = {data.name}
                rank = {data.rank}
                id = {data.id}
                src = {data.src}
                sale_rate = {data.sale_rate}
                gpa = {data.gpa}
            />
        )
    )
	return(
		<div id="Now_Posts_wrap">
            {slice_now}
		</div>
	)
}

export default Now_Posts;