import React, {useState,useEffect} from "react";
import "./css/Detail_Board.css";
import queryString from "query-string";
import axios from "axios";
import User_review from "./User_review.js";


function Detail_Board(props){
    const [user_review,set_user_review] = useState([]);

    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search)
        console.log("BDetail",queryObj.id)
        console.log("BDetail",queryObj.writer)

        get_user_review(queryObj.id,queryObj.writer);
    },[])

    const get_user_review = async(id,writer) => {
        const res = await axios.get(`/api/get/user_review${id}&${writer}`)
        set_user_review(res.data.user_review)
    }

    const user_review_map = user_review.map(
        (data,index)=> (
            <User_review
                key = {index}
                data = {data}
            />
        )
    )

	return(
		<div id="Detail_Board_wrap">
            {user_review_map}
		</div>
	)
}

export default Detail_Board;