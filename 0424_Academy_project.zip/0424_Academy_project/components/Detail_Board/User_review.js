import React, {useState} from "react";
import "./css/User_review.css";


function User_review(props){
    console.log("USER",props)
	return(
		<div id="User_review_wrap">
            <header>
                <div className="title">
                    <div className="title_head">
                        제목
                    </div>
                    <div className="title_text">
                        {props.data.title}
                    </div>
                </div>
                <div className="sub_info">
                    <div className="writer_head">
                        작성자
                    </div>
                    <div className="writer_text">
                        {props.data.writer}
                    </div>
                </div>
            </header>
            <div className="profile_wrap">
                <div className="profile">
                    <img src="https://i.pinimg.com/474x/7d/56/56/7d5656879b5d6ed45779f89c4e89c91a.jpg"></img>
                </div>
                <div className="name">
                    {props.data.writer}
                </div>
            </div>
            
		</div>
	)
}

export default User_review;