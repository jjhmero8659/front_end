import React , {useEffect, useState} from "react";
import "./css/Model_color_ffs.css";


function Model_color_ffs(props){
    return(
        <div id="Model_color_ffs_wrap">
            <p>컬러</p>
            <div className="color_select_wrap">
                <div className="black">
                    <div className="color"></div>
                </div>
                <div className="silver">
                    <div className="color"></div>
                </div>
                <div className="green">
                    <div className="color"></div>
                </div>
                <div className="pinkgold">
                    <div className="color"></div>
                </div>
            </div>
        </div>
    )
}

export default Model_color_ffs;