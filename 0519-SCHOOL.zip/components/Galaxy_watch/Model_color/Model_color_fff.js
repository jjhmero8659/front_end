import React , {useEffect, useState} from "react";
import "./css/Model_color_fff.css";


function Model_color_fff(props){
    return(
        <div id="Model_color_fff_wrap">
            <p>컬러</p>
        </div>
    )
}

export default Model_color_fff;