import React , {useEffect, useState} from "react";
import "./css/Galaxy_watch.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Model_first from "./Model_first.js";
import Model_second from "./Model_second.js";

import Model_color_fff from "./Model_color/Model_color_fff.js";
import Model_color_ffs from "./Model_color/Model_color_ffs.js";





function Galaxy_watch(props){

    const [model,set_model] = useState("first");
    const [sys_Ty,set_sys_Ty] = useState("first");
    const [get_size,set_get_size] = useState("first");

    const model_click = (click_data) =>{
        set_model(click_data)
        if(click_data == "first"){
            set_get_size("first")
        }
        else{
            set_get_size("third")
        }
        
    }


    const settings = {
        // fade : true,
        dots: false,
        autoplay:false,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };
    if(model == "first"){
        var model_size = <Model_first
            set_get_size = {set_get_size}
        />
    }
    else{
        var model_size = <Model_second
            set_get_size = {set_get_size}
        />
    }

    if(model == "first" && sys_Ty == "first" && get_size == "first"){
        var model_color = <Model_color_fff/>
    }
    else if(model == "first" && sys_Ty == "first" && get_size == "second"){
        var model_color = <Model_color_ffs/>
    }

    return(
        <div id="Galaxy_watch_wrap">
            <div className="top_img_timer">
                <img src="/img/Slide_Banner/galaxy_watch/banner_timer.png"></img>
            </div>

            <div className="buy_model">
                <p className="header_p">Galaxy Watch4 <i>I</i> Watch4 Classic</p>
                <h2>우리 가족 건강 관리는 갤럭시 워치로!</h2>

                <div className="slick_wrap">
                    <Slider {...settings}>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch1.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch2.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch3.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch4.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch5.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch6.jpg"></img>
                        </div>
                    </Slider>
                </div>
                <div className="right_side">
                    <div className="model">
                        <p>제품</p>
                        <div className="button_wrap">
                            <div className={model == "first" ? "left_button active" : "left_button"} onClick={()=>model_click("first")}>
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch.jpg"></img>
                                <p>갤럭시 워치4</p>
                            </div>

                            <div className={model == "second" ? "right_button active" : "right_button"} onClick={()=>model_click("second")}>
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch2.jpg"></img>
                                <p>갤럭시 워치4 클래식</p>
                            </div>
                        </div>
                    </div>

                    <div className="sys_Ty">
                        <p>구분</p>
                        <div className="button_wrap">
                            <div className={sys_Ty == "first" ? "left_button active" : "left_button"} onClick={()=>set_sys_Ty("first")}>
                                <p>블루투스</p>
                            </div>

                            <div className={sys_Ty == "second" ? "right_button active" : "right_button"} onClick={()=>set_sys_Ty("second")}>
                                <p>LTE자급제</p>
                            </div>
                        </div>
                    </div>


                    <div className="size">
                        {model_size}
                    </div>

                    <div className="color">
                        {model_color}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Galaxy_watch;