import React , {useEffect, useState} from "react";
import "./css/Model_first.css";


function Model_first(props){
    const [size_select,set_size_select] = useState("");
    console.log(props.size)

    useEffect(()=>{
        console.log("props.size_first",props.size)
        set_size_select(props.size)
    },[])

    const size_data = (size_data) => {
        props.set_get_size(size_data)
    }

    return(
        <div id="Model_first_wrap">
            <p>크기</p>
            <div className="watch_size">
                <div className={size_select == "first" ? "40mm active" : "40mm"} onClick={()=>set_size_select("first")}>
                    40mm
                </div >
                <div className={size_select == "second" ? "44mm active" : "44mm"} onClick={()=>set_size_select("second")}>
                    44mm
                </div>
                <div className="42mm">
                    42mm
                </div>
                <div className="46mm">
                    46mm
                </div>
            </div>
            
        </div>
    )
}

export default Model_first;