import React , {useEffect, useState} from "react";
import "./css/Galaxy_watch.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import Sys_hide from "./Sys_hide.js";
import Sys from "./Sys.js";

import Model_first from "./Model_first.js";
import Model_second from "./Model_second.js";

import Model_color_fff from "./Model_color/Model_color_fff.js";
import Model_color_ffs from "./Model_color/Model_color_ffs.js";
import Model_color_classic from "./Model_color/Model_color_classic.js";





function Galaxy_watch(props){

    const [model,set_model] = useState(""); //model 값
    const [sys_Ty,set_sys_Ty] = useState("");    //구분
    const [get_size,set_get_size] = useState(""); //크기
    const [color,set_color] = useState(""); //하위 컬러 색깔

    const model_click = (click_data) =>{
        set_model(click_data)
        set_get_size("")
    }

    const sys_ty_click = (click_data) => {
        set_get_size("")
    }


    const settings = {
        // fade : true,
        dots: false,
        autoplay:false,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
 
    };
    if(model == ""){
        var model_sys = <Sys_hide

        />
    }
    else{
        var model_sys = <Sys

        />
    }

    // if(model == "first"){
    //     var model_size = <Model_first
    //         size = {get_size} //size 변수 상속
    //         set_get_size = {set_get_size} //size 변동 함수 상속
    //     />
    // }
    // else{
    //     var model_size = <Model_second
    //         size = {get_size} //size 변수 상속
    //         set_get_size = {set_get_size} //size 변동 함수 상속
    //     />
    // }

    if( (model == "first" && sys_Ty == "first" && get_size == "first") || (model == "first" && sys_Ty == "second" && get_size == "first")){  /*블실핑 */
        var model_color = <Model_color_fff

        />
    }
    else if( (model == "first" && sys_Ty == "first" && get_size == "second") || (model == "first" && sys_Ty == "second" && get_size == "second")){ /*블실그*/
        var model_color = <Model_color_ffs

        />
    }
    else if((model == "second" && sys_Ty == "first" && get_size == "first") || (model == "second" && sys_Ty == "first" && get_size == "second") || (model == "second" && sys_Ty == "second" && get_size == "first") || (model == "second" && sys_Ty == "second" && get_size == "second")){
        var model_color = <Model_color_classic

        />
    }

    return(
        <div id="Galaxy_watch_wrap">
            <div className="top_img_timer">
                <img src="/img/Slide_Banner/galaxy_watch/banner_timer.png"></img>
            </div>

            <div className="buy_model">
                <p className="header_p">Galaxy Watch4 <i>I</i> Watch4 Classic</p>
                <h2>우리 가족 건강 관리는 갤럭시 워치로!</h2>

                <div className="slick_wrap">
                    <Slider {...settings}>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch1.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch2.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch3.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch4.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch5.jpg"></img>
                        </div>
                        <div>
                            <img src="/img/Slide_Banner/galaxy_watch/buy_product/galaxywatch6.jpg"></img>
                        </div>
                    </Slider>
                </div>
                <div className="right_side">
                    <div className="model">
                        <p>제품</p>
                        <div className="button_wrap">
                            <div className={model == "first" ? "left_button active" : "left_button"} onClick={()=>model_click("first")}>
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch.jpg"></img>
                                <p>갤럭시 워치4</p>
                            </div>

                            <div className={model == "second" ? "right_button active" : "right_button"} onClick={()=>model_click("second")}>
                                <img src="/img/Slide_Banner/galaxy_watch/buy_product/small_watch2.jpg"></img>
                                <p>갤럭시 워치4 클래식</p>
                            </div>
                        </div>
                    </div>

                    <div className="sys_Ty">
                        {model_sys}
                    </div>


                    {/* <div className="size">
                        {model_size}
                    </div>

                    <div className="color">
                        {model_color}
                    </div> */}
                </div>
            </div>
        </div>
    )
}

export default Galaxy_watch;