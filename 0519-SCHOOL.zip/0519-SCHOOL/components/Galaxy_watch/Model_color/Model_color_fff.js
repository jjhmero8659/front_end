import React , {useEffect, useState} from "react";
import "./css/Model_color_fff.css";


function Model_color_fff(props){

    const [color,set_color] = useState("")

    const color_select = (color) => {
        props.set_get_color(color)
        set_color(color)
    }

    return(
        <div id="Model_color_fff_wrap">
            <p>컬러</p>
            <div className="color_select_wrap">
                <div className={color == "black" ? "black_wrap active" : "black_wrap"}  onClick={()=>color_select("black")}>
                    <div className="color"></div>
                    <p>블랙</p>
                </div>
                <div className={color == "silver" ? "silver_wrap active" : "silver_wrap"} onClick={()=>color_select("silver")}>
                    <div className="color"></div>
                    <p>실버</p>
                </div>
                <div className="green">
                    <div className="color"></div>
                    <p>그린</p>
                </div>
                <div className={color == "pinkgold" ? "pinkgold_wrap active" : "pinkgold_wrap"} onClick={()=>color_select("pinkgold")}>
                    <div className="color"></div>
                    <p>핑크골드</p>
                </div>
            </div>
        </div>
    )
}

export default Model_color_fff;