import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/Best_Product.css";
import Best_Post from "./Best_Product/Post.js";

function Best_Product(props){

    const [Product,set_Product] = useState(props.Product)
    const [Represent_data,set_Represent_data] = useState([])

    useEffect(()=>{
        Representative_review();
    },[])

    const Representative_review = async() => {
        const res = await axios.get(`/api/get_represent/get_product`)
        set_Represent_data(res.data.data)
    }

    const Best_product_post = Represent_data.map(
        (data,index) => (
            <Best_Post
                key={index}
                data={data}
            />
        )
    )

    return(
        <div id="Best_Product_wrap">
            <div className="header">
                베스트 상품평
            </div>
            <div className="Posts_wrap">
                {Best_product_post}
            </div>
        </div>
    )
}

export default Best_Product;